package ru.rsreu.parshina0213;

public class RepeatWordDeleter {
	
	private RepeatWordDeleter() {
		
	}
	
	public static String deleteRepetitionsLastWord(String input) {
		String stringWithoutSpaces = input.trim();
		String[] words = stringWithoutSpaces.split(" ");
		
		String result = "";
		int indexLastWord = words.length - 1;

		for (int i = 0; i < indexLastWord; i++) {
			if (words[i].compareTo(words[indexLastWord]) != 0) {
				result += words[i] + " ";
			}
		}
		 result += words[indexLastWord];
		 return result;
	}	

	public static String deleteRepetitions(String input) {
		String result = "";

		if (input.isEmpty()) {
			result = "String is empty";
		} else {
			result = deleteRepetitionsLastWord(input);
		}

		return result;
	}

}
