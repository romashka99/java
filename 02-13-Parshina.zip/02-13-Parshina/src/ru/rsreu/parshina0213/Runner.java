package ru.rsreu.parshina0213;

import java.util.Scanner;

public class Runner {

	private Runner() {
	}

	/**
	 * @param args
	 */

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.print("Enter number of strings: n = ");
		int stringCount = Integer.parseInt(in.next());
		in.nextLine();

		String[] stringArray = new String[stringCount];
		for (int i = 0; i < stringArray.length; i++) {
			System.out.println("Enter " + (i + 1) + ". string: ");
			stringArray[i] = in.nextLine();
		}
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < stringArray.length; i++) {
			result.append("Result " + (i + 1) + ". string: " + RepeatWordDeleter.deleteRepetitions(stringArray[i]))
					.append("\n");

		}
		System.out.println(result);

		// Task realization

		in.close();

	}

}
