package ru.rsreu.parshina0513.coffee;

import ru.rsreu.parshina0513.Resourcer;

public enum PhysicalConditionCoffeeClass {
	CORN(Resourcer.getString("message.corn"), 1000) {
		public double getKgPrice() {
			return PhysicalConditionCoffeeClass.getBasePrice();
		}
	},
	GROUND(Resourcer.getString("message.ground"), 500) {
		public double getKgPrice() {
			return PhysicalConditionCoffeeClass.getBasePrice()
					* PhysicalConditionCoffeeClass.GROUND_CLASS_MULTIPLICATOR;
		}
	},
	INSTANT_CANS(Resourcer.getString("message.instantCans"), 250) {
		public double getKgPrice() {
			return PhysicalConditionCoffeeClass.getBasePrice()
					* PhysicalConditionCoffeeClass.INSTANT_CANS_CLASS_MULTIPLICATOR;
		}
	},
	INSTANT_BAGS(Resourcer.getString("message.instantBags"), 25) {
		public double getKgPrice() {
			return PhysicalConditionCoffeeClass.getBasePrice()
					* PhysicalConditionCoffeeClass.INSTANT_BAGS_CLASS_MULTIPLICATOR;
		}
	};
	public static final double GROUND_CLASS_MULTIPLICATOR = 0.5;
	public static final double INSTANT_CANS_CLASS_MULTIPLICATOR = 2.5;
	public static final double INSTANT_BAGS_CLASS_MULTIPLICATOR = 2;

	private static double basePrice = 1;

	private int weigthOnePackage;
	private String name;

	public int getWeigthOnePackage() {
		return this.weigthOnePackage;
	}

	public String getName() {
		return this.name;
	}

	public static double getBasePrice() {
		return PhysicalConditionCoffeeClass.basePrice;
	}

	public static void setBasePrice(double basePrice) {
		PhysicalConditionCoffeeClass.basePrice = basePrice;
	}

	PhysicalConditionCoffeeClass(String name, int wigthOnePackage) {
		this.name = name;
		this.weigthOnePackage = wigthOnePackage;
	}

	public abstract double getKgPrice();

}
