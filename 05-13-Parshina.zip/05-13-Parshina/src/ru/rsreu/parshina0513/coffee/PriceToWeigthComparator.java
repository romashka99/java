package ru.rsreu.parshina0513.coffee;

import java.util.Comparator;

public class PriceToWeigthComparator implements Comparator<Coffee> {
	@Override
	public int compare(Coffee o1, Coffee o2) {
		return -(o1.getPriceToWeigth() - o1.getPriceToWeigth());
	}
}
