package ru.rsreu.parshina0513.coffee;

import ru.rsreu.parshina0513.Resourcer;

public abstract class Coffee implements Comparable<Coffee> {
	private static final double DENSITY_COFFEE = 0.56;
	private int volume;
	private PhysicalConditionCoffeeClass physicalConditionCoffee;

	public Coffee(int volume, PhysicalConditionCoffeeClass physicalConditionCoffee) {
		this.setVolume(volume);
		this.setPhysicalConditionCoffee(physicalConditionCoffee);
	}

	public final int getVolume() {
		return this.volume;
	}

	public final void setVolume(int volume) {
		this.volume = volume;
	}

	public final PhysicalConditionCoffeeClass getPhysicalConditionCoffee() {
		return this.physicalConditionCoffee;
	}

	public final void setPhysicalConditionCoffee(PhysicalConditionCoffeeClass physicalConditionCoffee) {
		this.physicalConditionCoffee = physicalConditionCoffee;
	}

	public int getWeigth() {
		int weigthOnePackage = (int) (this.getVolume() * Coffee.DENSITY_COFFEE);
		return weigthOnePackage;
	}

	public int getCountItemPackage() {
		int weigthOnePackage = (int) (this.getWeigth() / this.getPhysicalConditionCoffee().getWeigthOnePackage());
		return weigthOnePackage;
	}

	public double getPriceForWeigth(double priceKilogram) {
		double weigth = this.getWeigth();
		return priceKilogram * weigth;
	}

	public double getPriceForVariety() {
		return this.getPhysicalConditionCoffee().getKgPrice();
	}

	public abstract double getPriceCoffee();

	public int getPriceToWeigth() {
		double priceToWeigth = this.getPriceCoffee() / this.getWeigth();
		int valuePriceToWeigth = (int) priceToWeigth;
		return valuePriceToWeigth;
	}

	@Override
	public int compareTo(Coffee coffee) {
		return -(this.hashCode() - coffee.hashCode());
	}

	@Override
	public int hashCode() {
		return this.getVolume() + (int) this.getPhysicalConditionCoffee().getKgPrice()
				+ (int) this.getPhysicalConditionCoffee().getWeigthOnePackage();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Coffee other = (Coffee) obj;
		if (this.volume != other.getVolume()) {
			return false;
		}
		if (this.physicalConditionCoffee != other.getPhysicalConditionCoffee()) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return this.getPhysicalConditionCoffee().getName() + String.format(
				Resourcer.getString("message.format"), this.getVolume(), this.getWeigth(), this.getPriceCoffee());
	}

}
