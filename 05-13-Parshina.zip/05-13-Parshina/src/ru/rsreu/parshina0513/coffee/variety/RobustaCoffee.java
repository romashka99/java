package ru.rsreu.parshina0513.coffee.variety;

import ru.rsreu.parshina0513.Resourcer;
import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffee.PhysicalConditionCoffeeClass;

public class RobustaCoffee extends Coffee {
	private static final double PRICE_GRAM = 1.43;
	private static final int MUlTIPLICATOR_GREIN_LENGTH = 10;
	private int grainLength;

	public RobustaCoffee(int volume, PhysicalConditionCoffeeClass physicalConditionCoffee, int grainLength) {
		super(volume, physicalConditionCoffee);
		this.setGrainLength(grainLength);
	}

	public int getGrainLength() {
		return grainLength;
	}

	public void setGrainLength(int grainLength) {
		this.grainLength = grainLength;
	}

	public double getPriceCoffee() {
		return super.getPriceForWeigth(PRICE_GRAM) * super.getPriceForVariety()
				* (4 * this.grainLength / MUlTIPLICATOR_GREIN_LENGTH);
	}

	@Override
	public String toString() {
		return Resourcer.getString("message.robusta") + " " + super.toString() + " "
				+ Resourcer.getString("message.grainLength") + " " + this.grainLength;
	}
}
