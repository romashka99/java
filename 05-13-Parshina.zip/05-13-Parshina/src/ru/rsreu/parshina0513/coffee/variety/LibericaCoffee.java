package ru.rsreu.parshina0513.coffee.variety;

import ru.rsreu.parshina0513.Resourcer;
import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffee.PhysicalConditionCoffeeClass;

public class LibericaCoffee extends Coffee {
	private static final double PRICE_GRAM = 0.62;
	private static final int MUlTIPLICATOR_GREIN_COUNT = 1000;
	private int countGrain;

	public LibericaCoffee(int volume, PhysicalConditionCoffeeClass physicalConditionCoffee, int countGrain) {
		super(volume, physicalConditionCoffee);
		this.setCountGrains(countGrain);
	}

	public int getCountGrains() {
		return countGrain;
	}

	public void setCountGrains(int countGrain) {
		this.countGrain = countGrain;
	}

	public double getPriceCoffee() {
		return super.getPriceForWeigth(PRICE_GRAM) * super.getPriceForVariety()
				* (this.countGrain / MUlTIPLICATOR_GREIN_COUNT);
	}

	@Override
	public String toString() {
		return Resourcer.getString("message.liberica") + " " + super.toString() + " "
				+ Resourcer.getString("message.countGrain") + " " + this.countGrain;
	}
}
