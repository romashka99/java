package ru.rsreu.parshina0513.coffee.variety;

import ru.rsreu.parshina0513.Resourcer;
import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffee.PhysicalConditionCoffeeClass;

public class ExcelsaCoffee extends Coffee {
	private static final double PRICE_GRAM = 0.65;
	private static final int MUlTIPLICATOR_TREE_HEIGHT = 10;
	private int treeHeight;

	public ExcelsaCoffee(int volume, PhysicalConditionCoffeeClass physicalConditionCoffee, int treeHeight) {
		super(volume, physicalConditionCoffee);
		this.setTreeHeight(treeHeight);
	}

	public int getTreeHeight() {
		return treeHeight;
	}

	public void setTreeHeight(int treeHeight) {
		this.treeHeight = treeHeight;
	}

	public double getPriceCoffee() {
		return super.getPriceForWeigth(PRICE_GRAM) * super.getPriceForVariety()
				* (2 * treeHeight / MUlTIPLICATOR_TREE_HEIGHT);
	}

	@Override
	public String toString() {
		return Resourcer.getString("message.excelsa") + " " + super.toString() + " "
				+ Resourcer.getString("message.treeHeight") + " " + this.treeHeight;
	}
}
