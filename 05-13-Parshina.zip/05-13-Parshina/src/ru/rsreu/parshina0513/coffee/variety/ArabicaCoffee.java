package ru.rsreu.parshina0513.coffee.variety;

import ru.rsreu.parshina0513.Resourcer;
import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffee.PhysicalConditionCoffeeClass;

public class ArabicaCoffee extends Coffee {
	private static final double PRICE_GRAM = 2.150;
	private static final int MUlTIPLICATOR_SEA_LEVEL = 100;
	private int aboveSeaLevel;

	public ArabicaCoffee(int volume, PhysicalConditionCoffeeClass physicalConditionCoffee, int adoveSeaLevel) {
		super(volume, physicalConditionCoffee);
		this.setAdoveSeaLevel(adoveSeaLevel);
	}

	public int getAdoveSeaLevel() {
		return aboveSeaLevel;
	}

	public void setAdoveSeaLevel(int adoveSeaLevel) {
		this.aboveSeaLevel = adoveSeaLevel;
	}

	public double getPriceCoffee() {
		return super.getPriceForWeigth(PRICE_GRAM) * super.getPriceForVariety()
				* (aboveSeaLevel / MUlTIPLICATOR_SEA_LEVEL);
	}

	@Override
	public String toString() {
		return Resourcer.getString("message.arabica") + " " + super.toString() + " "
				+ Resourcer.getString("message.aboveSeaLevel") + " " + this.aboveSeaLevel;
	}

}
