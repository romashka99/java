package ru.rsreu.parshina0513.coffeevan;

import java.util.Arrays;

import ru.rsreu.parshina0513.Resourcer;
import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffee.PriceToWeigthComparator;

public class CoffeeVan {
	public static final double VOLUME = 1000;
	private Coffee[] cargo;

	public CoffeeVan() {
		this.setCargo();
	}

	public final double getPrice() {
		int sumPrice = 0;
		for (int i = 0; i < this.cargo.length; i++) {
			sumPrice += cargo[i].getPriceCoffee();
		}
		return sumPrice;
	}

	public final void setCargo() {
		CoffeeVanInitializer initializator = new CoffeeVanInitializer();
		this.cargo = initializator.getCargo();
	}

	public Coffee[] getCargo() {
		return this.cargo;
	}

	public String findProduct(Coffee coffee) {
		String result = "";
		int index = Arrays.binarySearch(this.cargo, coffee);
		if (index > 0) {
			result = Resourcer.getString("message.foundItem");
		} else {
			result = Resourcer.getString("message.notfoundItem");
		}
		return result;
	}

	public void sortCargo() {
		PriceToWeigthComparator comparator = new PriceToWeigthComparator();
		Arrays.sort(this.cargo, comparator);
	}

	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i < this.cargo.length; i++) {
			s += this.cargo[i].toString() + "\n";
		}
		return s;
	}

}
