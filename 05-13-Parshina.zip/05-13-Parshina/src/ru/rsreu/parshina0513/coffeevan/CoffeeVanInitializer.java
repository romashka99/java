package ru.rsreu.parshina0513.coffeevan;

import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffee.PhysicalConditionCoffeeClass;
import ru.rsreu.parshina0513.coffee.variety.ArabicaCoffee;
import ru.rsreu.parshina0513.coffee.variety.ExcelsaCoffee;
import ru.rsreu.parshina0513.coffee.variety.LibericaCoffee;
import ru.rsreu.parshina0513.coffee.variety.RobustaCoffee;

public class CoffeeVanInitializer {
	public static final double VARIETY_MULTIPLICATOR = 4;
	public static final double PHYSICALCONDITION_MULTIPLICATOR = 4;
	public static final double ARABICA_MULTIPLICATOR = 0.4;
	public static final double ROBUSTA_MULTIPLICATOR = 0.4;
	public static final double EXCELSA_MULTIPLICATOR = 0.1;
	public static final double LIBERICA_MULTIPLICATOR = 0.1;
	public static final double BAGS_MULTIPLICATOR = 0.25;
	public static final double CANS_MULTIPLICATOR = 0.25;
	public static final double GROUND_MULTIPLICATOR = 0.3;
	public static final double CORN_MULTIPLICATOR = 0.2;
	public static final int SEA_LEVEL = 250;
	public static final int GRAIN_LENGTH = 2;
	public static final int TREE_HEIGHT = 2;
	public static final int COUNT_GRAINS = 2000;
	private Coffee[] cargo;

	CoffeeVanInitializer() {
		this.setCargo();
	}

	private int getVolumeArabica() {
		int volume = (int) (CoffeeVan.VOLUME * ARABICA_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeRobusta() {
		int volume = (int) (CoffeeVan.VOLUME * ROBUSTA_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeLiberica() {
		int volume = (int) (CoffeeVan.VOLUME * LIBERICA_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeExcelsa() {
		int volume = (int) (CoffeeVan.VOLUME * EXCELSA_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeCorn(int volumeCoffee) {
		int volume = (int) (volumeCoffee * CORN_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeGround(int volumeCoffee) {
		int volume = (int) (volumeCoffee * GROUND_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeInstantBags(int volumeCoffee) {
		int volume = (int) (volumeCoffee * BAGS_MULTIPLICATOR);
		return volume;
	}

	private int getVolumeInstantCans(int volumeCoffee) {
		int volume = (int) (volumeCoffee * CANS_MULTIPLICATOR);
		return volume;
	}

	public void setCargo() {
		int countItem = (int) (PHYSICALCONDITION_MULTIPLICATOR * VARIETY_MULTIPLICATOR);
		cargo = new Coffee[countItem];
		int weigthArabica = this.getVolumeArabica();
		int weigthRobusta = this.getVolumeRobusta();
		int weigthLiberica = this.getVolumeLiberica();
		int weigthExcelsa = this.getVolumeExcelsa();

		cargo[0] = new ArabicaCoffee(this.getVolumeCorn(weigthArabica), PhysicalConditionCoffeeClass.CORN, SEA_LEVEL);
		cargo[1] = new ArabicaCoffee(this.getVolumeGround(weigthArabica), PhysicalConditionCoffeeClass.GROUND,
				SEA_LEVEL);
		cargo[2] = new ArabicaCoffee(this.getVolumeInstantBags(weigthArabica),
				PhysicalConditionCoffeeClass.INSTANT_BAGS, SEA_LEVEL);
		cargo[3] = new ArabicaCoffee(this.getVolumeInstantCans(weigthArabica),
				PhysicalConditionCoffeeClass.INSTANT_CANS, SEA_LEVEL);
		cargo[4] = new RobustaCoffee(this.getVolumeCorn(weigthRobusta), PhysicalConditionCoffeeClass.CORN,
				GRAIN_LENGTH);
		cargo[5] = new RobustaCoffee(this.getVolumeGround(weigthRobusta), PhysicalConditionCoffeeClass.GROUND,
				GRAIN_LENGTH);
		cargo[6] = new RobustaCoffee(this.getVolumeInstantBags(weigthRobusta),
				PhysicalConditionCoffeeClass.INSTANT_BAGS, GRAIN_LENGTH);
		cargo[7] = new RobustaCoffee(this.getVolumeInstantCans(weigthRobusta),
				PhysicalConditionCoffeeClass.INSTANT_CANS, GRAIN_LENGTH);
		cargo[8] = new LibericaCoffee(this.getVolumeCorn(weigthLiberica), PhysicalConditionCoffeeClass.CORN,
				COUNT_GRAINS);
		cargo[9] = new LibericaCoffee(this.getVolumeGround(weigthLiberica), PhysicalConditionCoffeeClass.GROUND,
				COUNT_GRAINS);
		cargo[10] = new LibericaCoffee(this.getVolumeInstantBags(weigthLiberica),
				PhysicalConditionCoffeeClass.INSTANT_BAGS, COUNT_GRAINS);
		cargo[11] = new LibericaCoffee(this.getVolumeInstantCans(weigthLiberica),
				PhysicalConditionCoffeeClass.INSTANT_CANS, COUNT_GRAINS);
		cargo[12] = new ExcelsaCoffee(this.getVolumeCorn(weigthExcelsa), PhysicalConditionCoffeeClass.CORN,
				TREE_HEIGHT);
		cargo[13] = new ExcelsaCoffee(this.getVolumeGround(weigthExcelsa), PhysicalConditionCoffeeClass.GROUND,
				TREE_HEIGHT);
		cargo[14] = new ExcelsaCoffee(this.getVolumeInstantBags(weigthExcelsa),
				PhysicalConditionCoffeeClass.INSTANT_BAGS, TREE_HEIGHT);
		cargo[15] = new ExcelsaCoffee(this.getVolumeInstantCans(weigthExcelsa),
				PhysicalConditionCoffeeClass.INSTANT_CANS, TREE_HEIGHT);
	}

	public Coffee[] getCargo() {
		return this.cargo;
	}

}
