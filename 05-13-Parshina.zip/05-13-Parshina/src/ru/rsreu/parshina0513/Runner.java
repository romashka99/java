package ru.rsreu.parshina0513;

import ru.rsreu.parshina0513.coffee.Coffee;
import ru.rsreu.parshina0513.coffeevan.CoffeeVan;

public class Runner {

	private Runner() {

	}

	public static void main(String[] args) {
		StringBuilder result = new StringBuilder();
		CoffeeVan van = new CoffeeVan();

		result.append(Resourcer.getString("message.array")).append(van.getPrice()).append("\n")
				.append(Resourcer.getString("message.vanBefore")).append("\n").append(van).append("\n");
		van.sortCargo();
		result.append(Resourcer.getString("message.vanAfter")).append("\n").append(van).append("\n");

		Coffee findItem = van.getCargo()[1];
		result.append(findItem).append(" - ").append(van.findProduct(findItem));

		System.out.print(result);
	}

}
