package ru.rsreu.parshina0413;

import com.prutzkow.twodimarray.Matrix;

/**
 * Class NearestMinimalElementSearcher.
 * 
 * @autor Parshina Anna Romanovna
 */

public class NearestMinimalElementSearcher extends Matrix {

	/**
	 * Constructor - create new object
	 * 
	 * @see NearestMinimalElementSearcher#NearestMinimalElementSearcher(int, int)
	 */
	public NearestMinimalElementSearcher(int sizeX, int sizeY) throws IllegalArgumentException {
		super(sizeX, sizeY);
	}

	/**
	 * Function for find the value minimal array element
	 * 
	 * @return value minimal element
	 */
	private int searchMinimalElement() {
		int minimal = super.arrayBody[0][0];
		for (int i = 0; i < super.arrayBody.length; i++) {
			for (int j = 0; j < super.arrayBody[i].length; j++) {
				if (super.arrayBody[i][j] < minimal) {
					minimal = super.arrayBody[i][j];
				}
			}
		}
		return minimal;
	}

	/**
	 * Procedure for find coordinates nearest minimal element
	 * 
	 * @param minimal - minimal value of array
	 * 
	 * @return coordinates
	 */
	private CoordinatesElement searchCoordinatesNearestElement(int minimal) {
		int minimalRow = 0;
		int minimalColumn = 0;
		for (int i = 0; i < super.arrayBody.length; i++) {
			for (int j = 0; j < super.arrayBody[i].length; j++) {
				if (super.arrayBody[i][j] == minimal) {
					minimalRow = i + 1;
					minimalColumn = j + 1;
				}
			}
		}
		CoordinatesElement coordinates = new CoordinatesElement(minimalRow, minimalColumn);
		return coordinates;
	}

	/**
	 * Procedure for fill the array with random numbers
	 * 
	 * @param lowLine
	 * @param upLine
	 */
	public void fill(int lowLine, int upLine) {
		for (int i = 0; i < super.arrayBody.length; i++) {
			for (int j = 0; j < super.arrayBody[i].length; j++) {
				super.arrayBody[i][j] = lowLine + (int) (Math.random() * upLine);
			}
		}
	}

	/**
	 * Function for search the coordinates of the nearest minimal element
	 * 
	 * @return string with coordinates
	 */
	public StringBuilder searchCoordinatesNearestMinimalElement() {
		int minimal = searchMinimalElement();
		CoordinatesElement coordinates = this.searchCoordinatesNearestElement(minimal);
		StringBuilder result = new StringBuilder();
		result.append(String.format(Resourcer.getString("message.format"), minimal, coordinates.getRow(),
				coordinates.getColumn())).append(Resourcer.getString("message.nearestElement"));
		return result;
	}

	/**
	 * Function for get the count of the first row
	 * 
	 * @return count of the first row
	 */
	private int getlengthFirstRow() {
		return super.arrayBody[0].length;
	}

	private String outputArray() {
		String s = "";
		for (int i = 0; i < super.getRowCount(); i++) {
			for (int j = 0; j < super.getRowLength(i); j++) {
				s += String.format(Resourcer.getString("message.format"), super.arrayBody[i][j], i + 1, j + 1);
			}
			s += "\n";
		}
		return s;
	}

	/**
	 * Override function from Object
	 * 
	 * @return string with array and count of the first row
	 */
	@Override
	public String toString() {
		return this.outputArray() + Resourcer.getString("message.lengthFirstRow") + this.getlengthFirstRow();
	}
}
