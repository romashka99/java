package ru.rsreu.parshina0413;

/**
 * Class CoordinatesElementGetter with fields row and column.
 * 
 * @autor Parshina Anna Romanovna
 */

public class CoordinatesElement {
	private int row;
	private int column;

	/**
	 * Constructor - create new object
	 * 
	 * @see CoordinatesElement#CoordinatesElementGetter(int, int)
	 */
	public CoordinatesElement(int row, int column) {
		this.row = row;
		this.column = column;
	}

	/**
	 * Function for get the value row element
	 * 
	 * @return value row element
	 */
	public final int getRow() {
		return this.row;
	}

	/**
	 * Function for get the value column element
	 * 
	 * @return value column element
	 */
	public final int getColumn() {
		return this.column;
	}

}
