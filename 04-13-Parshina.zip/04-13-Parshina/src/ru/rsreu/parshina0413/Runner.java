package ru.rsreu.parshina0413;

/**
 * Class Runner.
 * 
 * @autor Parshina Anna Romanovna
 */

public class Runner {

	/**
	 * Constructor - creating new object
	 * 
	 * @see Runner#Runner()
	 */
	private Runner() {

	}

	/**
	 * Procedure for start application
	 * 
	 * @param args - parameters of command string
	 */
	public static void main(String[] args) {
		NearestMinimalElementSearcher array = new NearestMinimalElementSearcher(3, 4);
		array.fill(1, 12);
		StringBuilder result = new StringBuilder();
		result.append(Resourcer.getString("message.array")).append("\n").append(array).append("\n")
				.append(array.searchCoordinatesNearestMinimalElement());
		System.out.println(result);
	}

}
