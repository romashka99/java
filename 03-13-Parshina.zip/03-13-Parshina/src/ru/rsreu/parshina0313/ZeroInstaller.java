package ru.rsreu.parshina0313;

import java.util.Arrays;

public class ZeroInstaller {
	private int[] arrayBody;

	public ZeroInstaller(int... args) {
		this.arrayBody = new int[args.length];
		setArrayElements(args);
	}

	public final void setArrayElements(int... args) {
		int length = args.length;
		for (int i = 0; i < length; i++) {
			this.arrayBody[i] = args[i];
		}
	}

	private int sumArrayEvenValuesElements() {
		int summ = 0;
		int length = this.arrayBody.length;
		for (int i = 0; i < length; i++) {
			if (arrayBody[i] % 2 == 0) {
				summ += arrayBody[i];
			}
		}
		return summ;
	}

	private int productArrayOddValuesElements() {
		int product = 1;
		int length = this.arrayBody.length;
		for (int i = 0; i < length; i++) {
			if (arrayBody[i] % 2 != 0) {
				product *= arrayBody[i];
			}
		}
		return product;
	}

	private int[] toZeroArrayPosiriveElements() {
		int length = this.arrayBody.length;
		int[] result = new int[length];
		for (int i = 0; i < length; i++) {
			if (arrayBody[i] > 0) {
				result[i] = 0;
			} else {
				result[i] = arrayBody[i];
			}
		}
		return result;
	}

	private int[] toZeroArrayNegativeElements() {
		int length = this.arrayBody.length;
		int[] result = new int[length];
		for (int i = 0; i < length; i++) {
			if (arrayBody[i] < 0) {
				result[i] = 0;
			} else {
				result[i] = arrayBody[i];
			}
		}
		return result;
	}

	public String toZeroArrayElements() {
		String result = "";
		int summ = this.sumArrayEvenValuesElements();
		int prod = this.productArrayOddValuesElements();
		if (summ > prod) {
			result = Arrays.toString(this.toZeroArrayPosiriveElements());
		}

		if (summ < prod) {
			result = Arrays.toString(this.toZeroArrayNegativeElements());
		}

		if (summ == prod) {
			result = Resourcer.getString("massege.result.array");
		}

		return result;
	}

	@Override
	public String toString() {
		return Arrays.toString(this.arrayBody);
	}
}
