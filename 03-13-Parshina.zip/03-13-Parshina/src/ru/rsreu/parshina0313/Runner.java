package ru.rsreu.parshina0313;

public class Runner {

	private Runner() {

	}

	public static void main(String[] args) {
		ZeroInstaller arrayObject = new ZeroInstaller(1, 2, -3, -6);

		StringBuilder result = new StringBuilder();
		result.append(Resourcer.getString("message.origin.array")).append(arrayObject).append("\n")
				.append(Resourcer.getString("message.result")).append(arrayObject.toZeroArrayElements());
		System.out.println(result);
	}

}
