package ru.rsreu.parshina0613;

import java.util.Scanner;

import ru.rsreu.parshina0613.file.FileStructureCreator;
import ru.rsreu.parshina0613.file.FolderStructureCreator;
import ru.rsreu.parshina0613.transportcompany.TransportCompanyInitializer;

public class Runner {

	private Runner() {

	}

	public static void main(String[] args) {
		StringBuilder result = new StringBuilder();
		FolderStructureCreator folderStructure = new FolderStructureCreator();
		result.append(Resourcer.getString("message.directory")).append("\n").append(folderStructure.create())
				.append("\n");
		
		FileStructureCreator fileStructure = new FileStructureCreator();
		String resultCreateFileData = fileStructure.createFillFileData();
		result.append(String.format(Resourcer.getString("message.file"), Resourcer.getString("files.folder.data.name")))
				.append("\n").append(resultCreateFileData).append("\n");

		if (resultCreateFileData.contains(Resourcer.getString("message.fileWrite"))) {
			String resultCopy = fileStructure.copyFileData();
			result.append(
					String.format(Resourcer.getString("message.copy"), Resourcer.getString("files.folder.data.name"),
							Resourcer.getString("files.folder.backup.extension")))
					.append("\n").append(resultCopy).append("\n");

			if (resultCopy.contains(Resourcer.getString("message.fileCopy"))) {
				TransportCompanyInitializer source = new TransportCompanyInitializer();
				source.fillCompanies();
				result.append(Resourcer.getString("message.arraySource")).append("\n")
						.append(TableCreator.getTable(source));

				TransportCompanyInitializer copy = new TransportCompanyInitializer();
				String resultCopyArray = copy.fillCompaniesFromFile(
						System.getProperty("user.dir") + Resourcer.getString("files.folder.backup.extension"));

				result.append(String.format(Resourcer.getString("message.fillingArray"),
						Resourcer.getString("message.arrayCopy"), Resourcer.getString("files.folder.backup.extension")))
						.append("\n").append(resultCopyArray).append("\n");

				if (resultCopyArray == Resourcer.getString("message.fillArray")) {
					result.append(Resourcer.getString("message.arrayCopy")).append("\n")
							.append(TableCreator.getTable(copy));

				}
				Scanner in = new Scanner(System.in);
				System.out.print(result);
				result = new StringBuilder();
				System.out.print(String.format(Resourcer.getString("messege.question.move"),
						Resourcer.getString("files.folder.data.name")));
				String resultInput = in.next();
				resultInput = resultInput.toUpperCase();
				in.nextLine();
				in.close();
				if (resultInput.contains("Y")) {
					String resultMove = fileStructure.moveFileData();
					result.append(resultMove).append("\n");
					if (resultMove.contains(Resourcer.getString("message.fileMove"))) {

						TransportCompanyInitializer move = new TransportCompanyInitializer();
						String resultMoveArray = move.fillCompaniesFromFile(
								System.getProperty("user.dir") + Resourcer.getString("files.folder.move.data"));

						result.append(String.format(Resourcer.getString("message.fillingArray"),
								Resourcer.getString("message.arrayMove"),
								Resourcer.getString("files.folder.move.data"))).append("\n").append(resultMoveArray)
								.append("\n");

						if (resultMoveArray == Resourcer.getString("message.fillArray")) {
							result.append(Resourcer.getString("message.arrayMove")).append("\n")
									.append(TableCreator.getTable(move));
							if (move.compereTwoCompany(source)) {
								result.append(String.format(Resourcer.getString("message.compereEqual"),
										Resourcer.getString("message.arrayMove"),
										Resourcer.getString("message.arraySource"))).append("\n");
							} else {
								result.append(String.format(Resourcer.getString("message.compereNotEqual"),
										Resourcer.getString("message.arrayMove"),
										Resourcer.getString("message.arraySource"))).append("\n");
							}
							if (move.compereTwoCompany(copy)) {
								result.append(String.format(Resourcer.getString("message.compereEqual"),
										Resourcer.getString("message.arrayMove"),
										Resourcer.getString("message.arrayCopy"))).append("\n");
							} else {
								result.append(String.format(Resourcer.getString("message.compereNotEqual"),
										Resourcer.getString("message.arrayMove"),
										Resourcer.getString("message.arrayCopy"))).append("\n");
							}
						}
					}
				}
				if (source.compereTwoCompany(copy)) {
					result.append(String.format(Resourcer.getString("message.compereEqual"),
							Resourcer.getString("message.arraySource"), Resourcer.getString("message.arrayCopy")));
				} else {
					result.append(String.format(Resourcer.getString("message.compereNotEqual"),
							Resourcer.getString("message.arraySource"), Resourcer.getString("message.arrayCopy")));
				}
			}
		}
		System.out.print(result);
	}

}
