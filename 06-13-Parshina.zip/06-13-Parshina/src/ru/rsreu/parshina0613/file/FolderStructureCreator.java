package ru.rsreu.parshina0613.file;

import java.io.File;

import ru.rsreu.parshina0613.Resourcer;

public class FolderStructureCreator {
	public FolderStructureCreator() {

	}

	private String createDirectories(String path) throws FileException {
		String result = "";
		final File directories = new File(System.getProperty("user.dir") + path);
		if (!directories.exists()) {
			if (directories.mkdir()) {
				result = String.format(Resourcer.getString("message.directoriesFormatCreated"),
						directories.getAbsolutePath());
			} else {
				throw new FileException(String.format(Resourcer.getString("message.directoriesFormatNotCreated"),
						directories.getAbsolutePath()));
			}
		} else {
			result = String.format(Resourcer.getString("message.directoriesFormatExists"),
					directories.getAbsolutePath());
		}
		return result;
	}

	private String createFolderStructure(String path) {
		String result = "";
		try {
			result = this.createDirectories(path);
		} catch (FileException exception) {
			result = exception.getMessage();
		}
		return result;
	}

	public String create() {
		StringBuilder result = new StringBuilder();
		result.append(this.createFolderStructure(Resourcer.getString("files.folder.source.name"))).append("\n")
				.append(this.createFolderStructure(Resourcer.getString("files.folder.copy.name"))).append("\n")
				.append(this.createFolderStructure(Resourcer.getString("files.folder.move.name"))).append("\n");
		return result.toString();
	}

}
