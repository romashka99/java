package ru.rsreu.parshina0613.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import ru.rsreu.parshina0613.Resourcer;
import ru.rsreu.parshina0613.transportcompany.TransportCompanyInitializer;

public class FileStructureCreator {

	private static final int LENGTH_BUFFER = 1024;
	private File fileData;

	public FileStructureCreator() {

	}

	private String createFileData() throws FileException, IOException {
		String result = "";
		fileData = new File(System.getProperty("user.dir") + Resourcer.getString("files.folder.data.name"));
		if (fileData.exists()) {
			result = String.format(Resourcer.getString("message.fileFormatExists"), fileData.getAbsolutePath());
		} else {
			if (fileData.createNewFile()) {
				result = String.format(Resourcer.getString("message.fileFormatCreated"), fileData.getAbsolutePath());
			} else {
				throw new FileException(
						String.format(Resourcer.getString("message.fileFormatNotCreated"), fileData.getAbsolutePath()));
			}
		}
		return result;
	}

	private String fillFileData(String data) throws IOException {
		String result = Resourcer.getString("message.fileWrite");
		FileWriter writer = new FileWriter(fileData);
		writer.write(data);
		writer.flush();
		writer.close();
		return result;
	}

	public String createFillFileData() {
		StringBuilder result = new StringBuilder();
		try {
			result.append(this.createFileData()).append("\n");
			TransportCompanyInitializer intializer = new TransportCompanyInitializer();
			intializer.fillCompanies();
			result.append(this.fillFileData(intializer.toString())).append("\n");
		} catch (IOException exception) {
			result.append(Resourcer.getString("message.fileWriteException"));
		} catch (FileException exception) {
			result.append(exception.getMessage());
		}
		return result.toString();
	}

	private String copyFileUsingStream(File source, File dest) throws IOException {
		String result = Resourcer.getString("message.fileCopy");
		InputStream is = null;
		OutputStream os = null;
		is = new FileInputStream(source);
		os = new FileOutputStream(dest);
		byte[] buffer = new byte[LENGTH_BUFFER];
		int length;
		while ((length = is.read(buffer)) > 0) {
			os.write(buffer, 0, length);
		}
		is.close();
		os.close();
		return result;
	}

	public String copyFileData() {
		StringBuilder result = new StringBuilder();
		File copyFile = new File(System.getProperty("user.dir") + Resourcer.getString("files.folder.backup.extension"));
		if (fileData.exists()) {
			try {
				if (!copyFile.createNewFile()) {
					copyFile.delete();
					copyFile.createNewFile();
				}
				result.append(
						String.format(Resourcer.getString("message.fileFormatCreated"), copyFile.getAbsolutePath()))
						.append("\n");
			} catch (IOException exception) {
				result.append(
						String.format(Resourcer.getString("message.fileFormatNotCreated"), copyFile.getAbsolutePath()))
						.append("\n");
			}
			try {
				result.append(copyFileUsingStream(fileData, copyFile)).append("\n");
			} catch (IOException exception) {
				result.append(Resourcer.getString("message.fileCopyException")).append("\n");
			}
		} else {
			result.append(
					String.format(Resourcer.getString("message.fileFormatNotCreated"), fileData.getAbsolutePath()))
					.append("\n");
		}
		return result.toString();
	}

	public String moveFileData() {
		StringBuilder result = new StringBuilder();
		File moveFile = new File(System.getProperty("user.dir") + Resourcer.getString("files.folder.move.data"));
		if (fileData.exists()) {
			if (!fileData.renameTo(moveFile)) {
				moveFile.delete();
				fileData.renameTo(moveFile);
			}
			result.append(String.format(Resourcer.getString("message.fileFormatCreated"), moveFile.getAbsolutePath()))
					.append("\n").append(Resourcer.getString("message.fileMove")).append("\n");

		} else {
			result.append(
					String.format(Resourcer.getString("message.fileFormatNotCreated"), fileData.getAbsolutePath()))
					.append("\n");
		}
		return result.toString();
	}

}
