package ru.rsreu.parshina0613;

import ru.rsreu.parshina0613.transportcompany.TransportCompany;
import ru.rsreu.parshina0613.transportcompany.TransportCompanyInitializer;

public class TableCreator {

	private static final int LENGTH_COLUMN_NUMBER = 15;
	private static final int LENGTH_COLUMN_SENDER = 20;
	private static final int LENGTH_COLUMN_VEHICLE = 40;

	private TableCreator() {

	}

	private static String getSeparatorColumn(int length) {
		StringBuilder separator = new StringBuilder();
		for (int i = 0; i < length; i++) {
			separator.append("-");
		}
		separator.append("+");
		return separator.toString();
	}

	private static String getSeparator() {
		StringBuilder separator = new StringBuilder();
		separator.append("+");
		separator.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_NUMBER))
				.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_SENDER))
				.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_VEHICLE))
				.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_SENDER));
		separator.append("\n");
		return separator.toString();
	}

	private static String getTableHead() {
		StringBuilder line = new StringBuilder();
		line.append(TableCreator.getSeparator());
		line.append(String.format(Resourcer.getString("message.formatTableHead"),
				Resourcer.getString("head.table.number"), Resourcer.getString("head.table.sender"),
				Resourcer.getString("head.table.nameVehicle"), Resourcer.getString("head.table.cargoCapacity")));
		line.append(TableCreator.getSeparator());
		return line.toString();
	}

	private static String getLineData(TransportCompany company) {
		StringBuilder line = new StringBuilder();
		line.append(String.format(Resourcer.getString("message.formatTable"), company.getNumberCargo(),
				company.getSender(), company.getVehicle().getName(), company.getVehicle().getCargoCapacity()));
		return line.toString();
	}

	public static String getTable(TransportCompanyInitializer arrayCompany) {
		StringBuilder table = new StringBuilder();
		table.append(TableCreator.getTableHead());
		TransportCompany[] companies = arrayCompany.getCompanies();
		for (int i = 0; i < companies.length; i++) {
			table.append(TableCreator.getLineData(companies[i]));
			table.append(TableCreator.getSeparator());
		}
		return table.toString();
	}

}
