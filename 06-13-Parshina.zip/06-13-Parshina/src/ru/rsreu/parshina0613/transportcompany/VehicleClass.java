package ru.rsreu.parshina0613.transportcompany;

import ru.rsreu.parshina0613.Resourcer;

public enum VehicleClass {
	TRUCK(Resourcer.getString("message.truck"), 250) {
	},
	CARGO_SHIP(Resourcer.getString("message.cargoShip"), 1000) {
	},
	CARGO_AIRPLANE(Resourcer.getString("message.cargoAirplane"), 2000) {
	};

	private String name;
	private int cargoCapacity;
	
	VehicleClass(String name, int cargoCapacity) {
		this.name = name;
		this.cargoCapacity = cargoCapacity;
	}

	public String getName() {
		return this.name;
	}

	public int getCargoCapacity() {
		return this.cargoCapacity;
	}

}
