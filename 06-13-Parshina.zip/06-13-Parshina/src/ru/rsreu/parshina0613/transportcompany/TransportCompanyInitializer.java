package ru.rsreu.parshina0613.transportcompany;

import java.io.FileReader;
import java.io.IOException;

import ru.rsreu.parshina0613.Resourcer;

public class TransportCompanyInitializer {
	public static final int COUNT_COMPANY = 5;
	public static final int CARGO1 = 1;
	public static final int CARGO2 = 2;
	public static final int CARGO3 = 3;
	public static final int CARGO4 = 4;
	public static final int CARGO5 = 5;
	public static final String SENDER1 = "����";
	public static final String SENDER2 = "����";

	private TransportCompany[] companies;

	public TransportCompanyInitializer() {
	}

	public TransportCompany[] getCompanies() {
		return this.companies;
	}

	private int getNamberCargo(int index) {
		int namberCargo = 0;
		if (index == 0) {
			namberCargo = CARGO1;
		}
		if (index == 1) {
			namberCargo = CARGO2;
		}
		if (index == 2) {
			namberCargo = CARGO3;
		}
		if (index == CARGO3) {
			namberCargo = CARGO4;
		}
		if (index == CARGO4) {
			namberCargo = CARGO5;
		}
		return namberCargo;
	}

	private String getSender(int index) {
		String sender = "";
		if (index >= 0 && index < CARGO3) {
			sender = SENDER1;
		}
		if (index >= CARGO3) {
			sender = SENDER2;
		}
		return sender;
	}

	private VehicleClass getVehicle(int index) {
		VehicleClass vehicle = null;
		if (index == 0 || index == 1) {
			vehicle = VehicleClass.TRUCK;
		}
		if (index >= 2 || index == CARGO3) {
			vehicle = VehicleClass.CARGO_SHIP;
		}
		if (index >= CARGO4) {
			vehicle = VehicleClass.CARGO_AIRPLANE;
		}
		return vehicle;
	}

	private TransportCompany addCompany(int index) {
		TransportCompany company;
		int numberCargo = this.getNamberCargo(index);
		String sender = this.getSender(index);
		VehicleClass vehicle = this.getVehicle(index);
		company = new TransportCompany(numberCargo, sender, vehicle);
		return company;
	}

	public String fillCompanies() {
		String result = "";
		companies = new TransportCompany[COUNT_COMPANY];
		for (int i = 0; i < this.companies.length; i++) {
			this.companies[i] = addCompany(i);
		}
		return result;
	}

	private String getCompanyFromFile(String path) throws IOException {
		FileReader reader = new FileReader(path);
		String buff = "";
		int c;
		while ((c = reader.read()) != -1) {
			buff += (char) c;
		}
		reader.close();
		return buff;
	}

	public String fillCompaniesFromFile(String path) {
		String result = Resourcer.getString("message.fillArray");
		try {
			String arrayFromFile = this.getCompanyFromFile(path);
			String[] company = arrayFromFile.split("\n");
			companies = new TransportCompany[company.length];
			for (int i = 0; i < company.length; i++) {
				String[] fields = company[i].split("/");
				VehicleClass vehicle = null;
				String vehiclefields = fields[2].trim();
				if (vehiclefields.contains(Resourcer.getString("message.truck"))) {
					vehicle = VehicleClass.TRUCK;
				}
				if (vehiclefields.contains(Resourcer.getString("message.cargoShip"))) {
					vehicle = VehicleClass.CARGO_SHIP;
				}
				if (vehiclefields.contains(Resourcer.getString("message.cargoAirplane"))) {
					vehicle = VehicleClass.CARGO_AIRPLANE;
				}
				companies[i] = new TransportCompany(Integer.parseInt(fields[0].trim()), fields[1].trim(), vehicle);
			}
		} catch (IOException exception) {
			return Resourcer.getString("message.fillArrayException");
		} catch (NumberFormatException exception) {
			return Resourcer.getString("message.fillArrayException");
		}

		return result;
	}

	public boolean compereTwoCompany(TransportCompanyInitializer other) {
		for (int i = 0; i < this.companies.length; i++) {
			if (this.companies[i].equals(other.getCompanies()[i])) {
				return false;
			}
		}
		return true;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < this.companies.length; i++) {
			result.append(this.companies[i]).append("\n");
		}
		return result.toString();
	}

}
