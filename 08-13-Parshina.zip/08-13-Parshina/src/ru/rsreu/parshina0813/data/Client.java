package ru.rsreu.parshina0813.data;

public class Client {
	private String family;
	private String name;

	public Client(String family, String name) {
		super();
		this.family = family;
		this.name = name;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Client [family=\" + family + \", name=\" + name + \"]";
	}
}
