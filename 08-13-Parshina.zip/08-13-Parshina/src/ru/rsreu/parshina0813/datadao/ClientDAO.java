package ru.rsreu.parshina0813.datadao;

import java.sql.SQLException;
import java.util.List;

public interface ClientDAO {

	List<String> selectInformationClient() throws SQLException;

}
