package ru.rsreu.parshina0813.datadao;

public class DBTypeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4357349579792186554L;

	public DBTypeException() {
		super();
	}

	public DBTypeException(String message) {
		super(message);
	}
}
