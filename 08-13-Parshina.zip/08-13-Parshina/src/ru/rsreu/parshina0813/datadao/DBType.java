package ru.rsreu.parshina0813.datadao;

import java.sql.SQLException;

import ru.rsreu.parshina0813.dboracle.OracleDBDaoFactory;

public enum DBType {
	ORACLE {
		@Override
		public DAOFactory getDAOFactory() {
			DAOFactory oracleDBDaoFactory = null;
			try {
				oracleDBDaoFactory = OracleDBDaoFactory.getInstance();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return oracleDBDaoFactory;
		}
	};

	public static DBType getTypeByName(String dbType) throws DBTypeException {
		try {
			return DBType.valueOf(dbType.toUpperCase());
		} catch (Exception e) {
			throw new DBTypeException();
		}
	}

	public abstract DAOFactory getDAOFactory();

}
