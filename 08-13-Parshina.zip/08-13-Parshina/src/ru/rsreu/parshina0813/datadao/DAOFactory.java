package ru.rsreu.parshina0813.datadao;

public abstract class DAOFactory {
	public static DAOFactory getInstance(DBType dbType) {
		DAOFactory result = dbType.getDAOFactory();
		return result;
	}

	public abstract ClientDAO getClientDAO();
}
