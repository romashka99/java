package ru.rsreu.parshina0813;

import java.sql.SQLException;
import java.util.List;

import ru.rsreu.parshina0813.datadao.ClientDAO;
import ru.rsreu.parshina0813.datadao.DAOFactory;
import ru.rsreu.parshina0813.datadao.DBType;
import ru.rsreu.parshina0813.dboracle.OracleClientDAO;
import ru.rsreu.parshina0813.triangle.Triangle;
import ru.rsreu.parshina0813.triangle.Triangles;

public class Runner {

	private Runner() {
	}

	public static void main(String[] args) {
		StringBuilder result = new StringBuilder();
		DAOFactory factory = DAOFactory.getInstance(DBType.ORACLE);
		ClientDAO clientDAO = factory.getClientDAO();

		try {
			List<String> client = clientDAO.selectInformationClient();
			result.append(Resourcer.getString("message.client"));
			result.append(client).append("\n");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.append(Resourcer.getString("message.triangles"));
			Triangles triangles = new Triangles();
			triangles.setTriangles(OracleClientDAO.getTriangles());
			result.append(triangles);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.append(Resourcer.getString("message.findTriangleNearestSquare"));
			result.append(OracleClientDAO.findTriangleNearestSquare()).append("\n");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.append(Resourcer.getString("message.findTriangleInscribedCiracle"));
			result.append(OracleClientDAO.findTriangleInscribedCiracle()).append("\n");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println(result);
	}

}
