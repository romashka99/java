package ru.rsreu.parshina0813.triangle;

import ru.rsreu.parshina0813.Resourcer;

public class Triangle {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + number;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Triangle other = (Triangle) obj;
		if (number != other.number)
			return false;
		return true;
	}

	private int number;
	private Point point1;
	private Point point2;
	private Point point3;

	public Triangle(int number, Point point1, Point point2, Point point3) {
		this.number = number;
		this.point1 = point1;
		this.point2 = point2;
		this.point3 = point3;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public Point getPoint1() {
		return point1;
	}

	public void setPoint1(Point point1) {
		this.point1 = point1;
	}

	public Point getPoint2() {
		return point2;
	}

	public void setPoint2(Point point2) {
		this.point2 = point2;
	}

	public Point getPoint3() {
		return point3;
	}

	public void setPoint3(Point point3) {
		this.point3 = point3;
	}

	@Override
	public String toString() {
		return String.format(Resourcer.getString("format.triangle"), this.number, this.point1, this.point2,
				this.point3);
	}

}
