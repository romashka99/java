package ru.rsreu.parshina0813.triangle;

import java.util.ArrayList;
import java.util.List;

public class Triangles {

	private List<Triangle> triangles;

	public Triangles() {
		triangles = null;
	}

	public void setTriangles(String inputTriangle) {
		triangles = new ArrayList<Triangle>();
		String[] triangle = inputTriangle.split("\n");
		for (int i = 0; i < triangle.length; i += 3) {
			String[] point1 = triangle[i].split(" ");
			String[] point2 = triangle[i + 1].split(" ");
			String[] point3 = triangle[i + 2].split(" ");
			triangles.add(new Triangle(Integer.parseInt(point1[0]),
					new Point(Integer.parseInt(point1[1]), Integer.parseInt(point1[2])),
					new Point(Integer.parseInt(point2[1]), Integer.parseInt(point2[2])),
					new Point(Integer.parseInt(point3[1]), Integer.parseInt(point3[2]))));
		}
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		for (Triangle item : triangles) {
			result.append(item).append("\n");
		}
		return result.toString();
	}
}
