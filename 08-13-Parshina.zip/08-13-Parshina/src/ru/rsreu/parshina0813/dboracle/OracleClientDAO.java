package ru.rsreu.parshina0813.dboracle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.parshina0813.datadao.ClientDAO;
import ru.rsreu.parshina0813.Resourcer;

public class OracleClientDAO implements ClientDAO {

	private static Connection connection;

	public OracleClientDAO(Connection connection) {
		OracleClientDAO.connection = connection;
	}

	public static String getTriangles() throws SQLException {
		StringBuilder resultList = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		pstmt = connection.prepareStatement(Resourcer.getString("sql.quaery.getTriangles"));
		result = pstmt.executeQuery();
		while (result.next()) {
			resultList.append(result.getString(1)).append(" ");
			resultList.append(result.getString(2)).append(" ");
			resultList.append(result.getString(3)).append(" ");
			resultList.append(result.getString(4)).append("\n");
		}
		return resultList.toString();
	}

	public static String findTriangleNearestSquare() throws SQLException {
		StringBuilder resultList = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		pstmt = connection.prepareStatement(Resourcer.getString("sql.quaery.findTriangleNearestSquare"));
		result = pstmt.executeQuery();
		while (result.next()) {
			resultList.append(result.getString(1));
		}
		return resultList.toString();
	}

	public static String findTriangleInscribedCiracle() throws SQLException {
		StringBuilder resultList = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		pstmt = connection.prepareStatement(Resourcer.getString("sql.quaery.findTriangleInscribedCiracle"));
		result = pstmt.executeQuery();
		while (result.next()) {
			resultList.append(result.getString(1)).append(" ");
		}
		return resultList.toString();
	}

	@Override
	public List<String> selectInformationClient() throws SQLException {
		List<String> resultList = new ArrayList<String>();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		pstmt = connection.prepareStatement(Resourcer.getString("sql.query.clientDB"));
		result = pstmt.executeQuery();
		while (result.next()) {
			resultList.add(result.getString(1));
			resultList.add(result.getString(2));
		}
		return resultList;
	}

}
