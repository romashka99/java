package ru.rsreu.parshina0813.dboracle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;

import ru.rsreu.parshina0813.datadao.ClientDAO;
import ru.rsreu.parshina0813.datadao.DAOFactory;
import ru.rsreu.parshina0813.Resourcer;

public class OracleDBDaoFactory extends DAOFactory {
	private static volatile OracleDBDaoFactory instance;
	private Connection connection;

	private OracleDBDaoFactory() {
	}

	public static OracleDBDaoFactory getInstance() throws ClassNotFoundException, SQLException {
		OracleDBDaoFactory factory = instance;
		if (instance == null) {
			synchronized (OracleDBDaoFactory.class) {
				factory = new OracleDBDaoFactory();
				instance = factory;
				factory.connected();
			}
		}
		return factory;
	}

	private void connected() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Locale.setDefault(Locale.PRC);
		StringBuilder result = new StringBuilder();
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "ANNA";
		String password = "111";
		connection = DriverManager.getConnection(url, user, password);
		result.append(Resourcer.getString("message.connect"));
		System.out.println(result);
	}

	@Override
	public ClientDAO getClientDAO() {
		return new OracleClientDAO(connection);
	}

}
