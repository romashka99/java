package ru.rsreu.parshina0713;

import java.util.Collection;

import ru.rsreu.parshina0713.transportcompany.TransportCompany;

public class TableCreator {

	private static final int LENGTH_COLUMN_NUMBER = 15;
	private static final int LENGTH_COLUMN_SENDER = 20;
	private static final int LENGTH_COLUMN_VEHICLE = 40;

	private TableCreator() {

	}

	private static String getSeparatorColumn(int length) {
		StringBuilder separator = new StringBuilder();
		for (int i = 0; i < length; i++) {
			separator.append("-");
		}
		separator.append("+");
		return separator.toString();
	}

	private static String getSeparator() {
		StringBuilder separator = new StringBuilder();
		separator.append("+");
		separator.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_NUMBER))
				.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_SENDER))
				.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_VEHICLE))
				.append(TableCreator.getSeparatorColumn(LENGTH_COLUMN_SENDER));
		separator.append("\n");
		return separator.toString();
	}

	private static String getTableHead() {
		StringBuilder line = new StringBuilder();
		line.append(TableCreator.getSeparator());
		line.append(String.format(Resourcer.getString("message.formatTableHead"),
				Resourcer.getString("head.table.number"), Resourcer.getString("head.table.sender"),
				Resourcer.getString("head.table.nameVehicle"), Resourcer.getString("head.table.cargoCapacity")));
		line.append(TableCreator.getSeparator());
		return line.toString();
	}

	private static String getLineData(TransportCompany company) {
		StringBuilder line = new StringBuilder();
		line.append(String.format(Resourcer.getString("message.formatTable"), company.getNumberCargo(),
				company.getSender(), company.getVehicle().getName(), company.getVehicle().getCargoCapacity()));
		return line.toString();
	}

	public static String formTable(Collection<TransportCompany> listCompany) {
		StringBuilder table = new StringBuilder();
		table.append(TableCreator.getTableHead());
		for (TransportCompany company : listCompany) {
			table.append(TableCreator.getLineData(company));
			table.append(TableCreator.getSeparator());
		}
		return table.toString();
	}

	public static String getList(Collection<String> listCompany) {
		StringBuilder result = new StringBuilder();
		for (String company : listCompany) {
			result.append(company).append("\n");
		}
		return result.toString();
	}

}
