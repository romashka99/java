package ru.rsreu.parshina0713;

import java.util.Collection;
import java.util.Set;

import ru.rsreu.parshina0713.transportcompany.TransportCompany;
import ru.rsreu.parshina0713.transportcompany.TransportCompanyInitializer;

public class Runner {
	private static final int COUNT_COMPANY = 5;

	private Runner() {

	}

	public static void main(String[] args) {
		StringBuilder result = new StringBuilder();
		TransportCompanyInitializer initializer = new TransportCompanyInitializer();
		Collection<TransportCompany> companies = initializer.getCompanies();

		result.append(Resourcer.getString("message.sourceList")).append("\n");
		result.append(TableCreator.formTable(companies));

		companies = initializer.sort();
		result.append(Resourcer.getString("message.sortDefault")).append("\n");
		result.append(TableCreator.formTable(companies));

		companies = initializer.sortTwoFields();
		result.append(Resourcer.getString("message.sort")).append("\n");
		result.append(TableCreator.formTable(companies));

		Set<String> companiesWithoutRepetition = initializer.getListForSecondFieldWithoutRepetition();
		result.append(Resourcer.getString("message.valuesSenderWithoutRepitition")).append("\n");
		result.append(TableCreator.getList(companiesWithoutRepetition));

		String nameVehicle = Resourcer.getString("message.cargoAirplane");
		companies = initializer.deleteItemForThird(nameVehicle);
		result.append(String.format(Resourcer.getString("message.deleteItem"), nameVehicle)).append("\n");
		result.append(TableCreator.formTable(companies));

		result.append(initializer.searchCompanyForFirstFields(initializer.getMap(), 1)).append("\n");
		result.append(initializer.searchCompanyForFirstFields(initializer.getMap(), COUNT_COMPANY)).append("\n");
		System.out.print(result);
	}

}
