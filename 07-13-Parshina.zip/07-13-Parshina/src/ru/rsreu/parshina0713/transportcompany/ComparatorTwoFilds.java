package ru.rsreu.parshina0713.transportcompany;

import java.util.Comparator;

public class ComparatorTwoFilds implements Comparator<TransportCompany> {

	@Override
	public int compare(TransportCompany o1, TransportCompany o2) {
		int firstFilds = o2.getSender().compareTo(o1.getSender());
		if (firstFilds != 0) {
			return firstFilds;
		} else {
			return o1.getVehicle().getName().compareTo(o2.getVehicle().getName());
		}
	}

}
