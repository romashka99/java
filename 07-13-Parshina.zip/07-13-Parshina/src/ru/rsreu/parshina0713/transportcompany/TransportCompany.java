package ru.rsreu.parshina0713.transportcompany;

import ru.rsreu.parshina0713.Resourcer;

public class TransportCompany implements Comparable<TransportCompany> {
	private int numberCargo;
	private String sender;
	private VehicleClass vehicle;

	public TransportCompany(int namberCargo, String sender, VehicleClass vehicle) {
		this.setNumberCargo(namberCargo);
		this.setSender(sender);
		this.setVehicle(vehicle);
	}

	public final int getNumberCargo() {
		return this.numberCargo;
	}

	public final void setNumberCargo(int namberCargo) {
		this.numberCargo = namberCargo;
	}

	public final String getSender() {
		return this.sender;
	}

	public final void setSender(String sender) {
		this.sender = sender;
	}

	public final VehicleClass getVehicle() {
		return this.vehicle;
	}

	public final void setVehicle(VehicleClass vehicle) {
		this.vehicle = vehicle;
	}

	@Override
	public int compareTo(TransportCompany company) {
		return -(this.hashCode() - company.hashCode());
	}

	@Override
	public int hashCode() {
		return this.getNumberCargo() + this.vehicle.getCargoCapacity();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		TransportCompany other = (TransportCompany) obj;
		if (this.numberCargo != other.getNumberCargo()) {
			return false;
		}
		if (this.sender != other.getSender()) {
			return false;
		}
		if (this.vehicle != other.getVehicle()) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return String.format(Resourcer.getString("message.format"), this.numberCargo, this.sender,
				this.vehicle.getName(), this.vehicle.getCargoCapacity());
	}
}
