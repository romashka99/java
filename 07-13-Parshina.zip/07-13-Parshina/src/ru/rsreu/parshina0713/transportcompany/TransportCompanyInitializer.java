package ru.rsreu.parshina0713.transportcompany;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ru.rsreu.parshina0713.Resourcer;

public class TransportCompanyInitializer {
	public static final int COUNT_COMPANY = 5;
	public static final int CARGO1 = 1;
	public static final int CARGO2 = 2;
	public static final int CARGO3 = 3;
	public static final int CARGO4 = 4;
	public static final int CARGO5 = 5;
	public static final String SENDER1 = "����";
	public static final String SENDER2 = "����";

	private List<TransportCompany> companies;

	public TransportCompanyInitializer() {
		this.fillCompanies();
	}

	public List<TransportCompany> getCompanies() {
		return this.companies;
	}

	private int getNamberCargo(int index) {
		int namberCargo = 0;
		if (index == 0) {
			namberCargo = CARGO1;
		}
		if (index == 1) {
			namberCargo = CARGO2;
		}
		if (index == 2) {
			namberCargo = CARGO3;
		}
		if (index == CARGO3) {
			namberCargo = CARGO4;
		}
		if (index == CARGO4) {
			namberCargo = CARGO5;
		}
		return namberCargo;
	}

	private String getSender(int index) {
		String sender = "";
		if (index >= 0 && index < CARGO3) {
			sender = SENDER1;
		}
		if (index >= CARGO3) {
			sender = SENDER2;
		}
		return sender;
	}

	private VehicleClass getVehicle(int index) {
		VehicleClass vehicle = null;
		if (index == 0 || index == 1) {
			vehicle = VehicleClass.TRUCK;
		}
		if (index >= 2 || index == CARGO3) {
			vehicle = VehicleClass.CARGO_SHIP;
		}
		if (index >= CARGO4) {
			vehicle = VehicleClass.CARGO_AIRPLANE;
		}
		return vehicle;
	}

	private TransportCompany addCompany(int index) {
		TransportCompany company;
		int numberCargo = this.getNamberCargo(index);
		String sender = this.getSender(index);
		VehicleClass vehicle = this.getVehicle(index);
		company = new TransportCompany(numberCargo, sender, vehicle);
		return company;
	}

	public void fillCompanies() {
		companies = new ArrayList<TransportCompany>();
		for (int i = 0; i < COUNT_COMPANY; i++) {
			this.companies.add(addCompany(i));
		}
	}

	public List<TransportCompany> sort() {
		Collections.sort(this.companies);
		return this.getCompanies();
	}

	public List<TransportCompany> sortTwoFields() {
		ComparatorTwoFilds comparator = new ComparatorTwoFilds();
		Collections.sort(this.companies, comparator);
		return this.getCompanies();
	}

	public Set<String> getListForSecondFieldWithoutRepetition() {
		Set<String> companiesWithoutRepetition = new HashSet<String>();
		for (TransportCompany company : this.companies) {
			companiesWithoutRepetition.add(company.getSender());
		}
		return companiesWithoutRepetition;
	}

	public List<TransportCompany> deleteItemForThird(String thirdField) {
		Iterator<TransportCompany> iterator = this.companies.iterator();
		while (iterator.hasNext()) {
			if (iterator.next().getVehicle().getName() == thirdField) {
				iterator.remove();
			}
		}
		return this.getCompanies();
	}

	public Map<Integer, TransportCompany> getMap() {
		Map<Integer, TransportCompany> listForSearch = new HashMap<Integer, TransportCompany>();
		for (TransportCompany company : this.companies) {
			listForSearch.put(company.getNumberCargo(), company);
		}
		return listForSearch;
	}

	public String searchCompanyForFirstFields(Map<Integer, TransportCompany> map, int numberCargo) {
		String result = "";
		if (map.containsKey(numberCargo)) {
			result = String.format(Resourcer.getString("message.formatFound"), numberCargo,
					map.get(numberCargo).toString());
		} else {
			result = String.format(Resourcer.getString("message.formatNotFound"), numberCargo);
		}
		return result;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		for (TransportCompany company : this.companies) {
			result.append(company).append("\n");
		}
		return result.toString();
	}

}
