package ru.rsreu.studentsregistration.command;

public enum TypeCommand {
	GET,
	POST,
	AJAX
}
