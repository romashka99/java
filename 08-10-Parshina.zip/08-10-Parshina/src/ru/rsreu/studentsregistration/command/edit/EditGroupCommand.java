package ru.rsreu.studentsregistration.command.edit;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.GroupDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EditGroupCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String code = request.getParameter("code");
		int idForm = Integer.parseInt(request.getParameter("form"));
		int idSpecialty = Integer.parseInt(request.getParameter("specialty"));
		int idDepartment = Integer.parseInt(request.getParameter("department"));
		DAOFactory factory = DAOFactory.getInstance();
		GroupDAO dao = factory.getGroupDAO();
		dao.updateGroup(id, code, idForm, idSpecialty, idDepartment);
		super.setUrl(ConfigurationManager.getProperty("url.get.infos"));
	}

}
