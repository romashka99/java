package ru.rsreu.studentsregistration.command.edit;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserGroupDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EditUserGroupCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		DAOFactory factory = DAOFactory.getInstance();
		UserGroupDAO dao = factory.getUserGroupDAO();
		dao.updateUserGroup(id, title);
		super.setUrl(ConfigurationManager.getProperty("url.get.usergroups"));
	}

}
