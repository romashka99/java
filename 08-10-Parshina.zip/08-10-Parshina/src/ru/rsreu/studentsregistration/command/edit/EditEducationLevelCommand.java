package ru.rsreu.studentsregistration.command.edit;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.EducationLevelDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EditEducationLevelCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		DAOFactory factory = DAOFactory.getInstance();
		EducationLevelDAO dao = factory.getEducationLevelDAO();
		dao.updateEducationLevel(id, title);
		super.setUrl(ConfigurationManager.getProperty("url.get.infos"));
	}

}
