package ru.rsreu.studentsregistration.command.edit;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.SpecialtyDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EditSpecialtyCommad extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String code = request.getParameter("code");
		String title = request.getParameter("title");
		int period = Integer.parseInt(request.getParameter("period"));
		int idLevel = Integer.parseInt(request.getParameter("level"));
		DAOFactory factory = DAOFactory.getInstance();
		SpecialtyDAO dao = factory.getSpecialtyDAO();
		dao.updateSpecialty(id, code, title, period, idLevel);
		super.setUrl(ConfigurationManager.getProperty("url.get.infos"));
	}

}
