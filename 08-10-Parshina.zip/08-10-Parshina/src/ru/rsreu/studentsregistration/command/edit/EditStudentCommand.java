package ru.rsreu.studentsregistration.command.edit;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.StudentDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EditStudentCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String firstName = request.getParameter("first-name");
		String secondName = request.getParameter("second-name");
		String patronymic = request.getParameter("patronymic");
		String sex = request.getParameter("sex");
		String birthDate = request.getParameter("birth-date");
		DAOFactory factory = DAOFactory.getInstance();
		StudentDAO dao = factory.getStudentDAO();
		dao.updateStudent(id, firstName, secondName, patronymic, sex, birthDate);
		super.setUrl(ConfigurationManager.getProperty("url.get.students"));
	}

}
