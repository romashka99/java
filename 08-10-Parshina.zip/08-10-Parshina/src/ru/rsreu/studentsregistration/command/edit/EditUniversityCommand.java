package ru.rsreu.studentsregistration.command.edit;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UniversityDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EditUniversityCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		String article = request.getParameter("article");
		String adress = request.getParameter("adress");
		DAOFactory factory = DAOFactory.getInstance();
		UniversityDAO dao = factory.getUniversityDAO();
		dao.updateUniversity(id, title, article, adress);
		super.setUrl(ConfigurationManager.getProperty("url.get.universities"));
	}

}
