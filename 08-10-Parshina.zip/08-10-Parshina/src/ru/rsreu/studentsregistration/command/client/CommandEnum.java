package ru.rsreu.studentsregistration.command.client;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.command.LoginCommand;
import ru.rsreu.studentsregistration.command.LogoutCommand;
import ru.rsreu.studentsregistration.command.SignedDecreeCommand;
import ru.rsreu.studentsregistration.command.add.AddDecreeCommand;
import ru.rsreu.studentsregistration.command.add.AddUniversityCommand;
import ru.rsreu.studentsregistration.command.add.AddUserCommand;
import ru.rsreu.studentsregistration.command.add.AddUserGroupCommand;
import ru.rsreu.studentsregistration.command.delete.DeleteDecreeCommand;
import ru.rsreu.studentsregistration.command.delete.DeleteUniversityCommand;
import ru.rsreu.studentsregistration.command.delete.DeleteUserCommand;
import ru.rsreu.studentsregistration.command.delete.DeleteUserGroupCommand;
import ru.rsreu.studentsregistration.command.edit.EditDecreeCommand;
import ru.rsreu.studentsregistration.command.edit.EditStudentCommand;
import ru.rsreu.studentsregistration.command.edit.EditUniversityCommand;
import ru.rsreu.studentsregistration.command.edit.EditUserCommand;
import ru.rsreu.studentsregistration.command.edit.EditUserGroupCommand;
import ru.rsreu.studentsregistration.command.get.GetDecreesCommand;
import ru.rsreu.studentsregistration.command.get.GetInfosCommand;
import ru.rsreu.studentsregistration.command.get.GetStudentGroupCommand;
import ru.rsreu.studentsregistration.command.get.GetStudentsCommand;
import ru.rsreu.studentsregistration.command.get.GetUniversitiesCommand;
import ru.rsreu.studentsregistration.command.get.GetUserGroupsCommand;
import ru.rsreu.studentsregistration.command.get.GetUsersCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormDepartmentCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormEducationFormCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormEducationLevelCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormFacultyCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormDecreeCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormStudentCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormUniversityCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormUserCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormUserGroupCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormGroupCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormLoginCommand;
import ru.rsreu.studentsregistration.command.get.form.GetFormSpecialtyCommand;

public enum CommandEnum {
	GET_FORM_LOGIN {
		{
			this.command = new GetFormLoginCommand();
		}
	},
	LOGIN {
		{
			this.command = new LoginCommand();
		}
	},
	LOGOUT {
		{
			this.command = new LogoutCommand();
		}
	},
	GET_STUDENTS {
		{
			this.command = new GetStudentsCommand();
		}
	},
	GET_DECREES {
		{
			this.command = new GetDecreesCommand();
		}
	},
	GET_USERS {
		{
			this.command = new GetUsersCommand();
		}
	},
	GET_USERGROUPS {
		{
			this.command = new GetUserGroupsCommand();
		}
	},
	GET_UNIVERSITIES {
		{
			this.command = new GetUniversitiesCommand();
		}
	},
	GET_FACYLTIES {
		{
			this.command = new GetFormFacultyCommand();
		}
	},
	GET_DEPARTMENTS {
		{
			this.command = new GetFormDepartmentCommand();
		}
	},
	GET_GROUPS {
		{
			this.command = new GetFormGroupCommand();
		}
	},
	GET_EDUCATION_LEVELS {
		{
			this.command = new GetFormEducationLevelCommand();
		}
	},
	GET_EDUCATION_FORMS {
		{
			this.command = new GetFormEducationFormCommand();
		}
	},
	GET_INFOS {
		{
			this.command = new GetInfosCommand();
		}
	},
	GET_FORM_USER {
		{
			this.command = new GetFormUserCommand();
		}
	},
	GET_FORM_DECREE {
		{
			this.command = new GetFormDecreeCommand();
		}
	},
	GET_FORM_STUDENT {
		{
			this.command = new GetFormStudentCommand();
		}
	},
	GET_FORM_USERGROUP {
		{
			this.command = new GetFormUserGroupCommand();
		}
	},
	GET_FORM_UNIVERSITY {
		{
			this.command = new GetFormUniversityCommand();
		}
	},
	GET_FORM_FACULTY {
		{
			this.command = new GetFormFacultyCommand();
		}
	},
	GET_FORM_DEPARTMENT {
		{
			this.command = new GetFormDepartmentCommand();
		}
	},
	GET_FORM_GROUP {
		{
			this.command = new GetFormGroupCommand();
		}
	},
	GET_FORM_SPECIALTY {
		{
			this.command = new GetFormSpecialtyCommand();
		}
	},
	GET_FORM_FORM {
		{
			this.command = new GetFormEducationFormCommand();
		}
	},
	GET_FORM_LEVEL {
		{
			this.command = new GetFormEducationLevelCommand();
		}
	},
	ADD_DECREE {
		{
			this.command = new AddDecreeCommand();
		}
	},
	EDIT_DECREE {
		{
			this.command = new EditDecreeCommand();
		}
	},
	DELETE_DECREE {
		{
			this.command = new DeleteDecreeCommand();
		}
	},
	SIGNED_DECREE {
		{
			this.command = new SignedDecreeCommand();
		}
	},
	EDIT_STUDENT {
		{
			this.command = new EditStudentCommand();
		}
	},
	ADD_USER {
		{
			this.command = new AddUserCommand();
		}
	},
	EDIT_USER {
		{
			this.command = new EditUserCommand();
		}
	},
	DELETE_USER {
		{
			this.command = new DeleteUserCommand();
		}
	},
	ADD_USERGROUP {
		{
			this.command = new AddUserGroupCommand();
		}
	},
	EDIT_USERGROUP {
		{
			this.command = new EditUserGroupCommand();
		}
	},
	DELETE_USERGROUP {
		{
			this.command = new DeleteUserGroupCommand();
		}
	},
	ADD_UNIVERSITY {
		{
			this.command = new AddUniversityCommand();
		}
	},
	EDIT_UNIVERSITY {
		{
			this.command = new EditUniversityCommand();
		}
	},
	DELETE_UNIVERSITY {
		{
			this.command = new DeleteUniversityCommand();
		}
	},
	GET_STUDENT_GROUP{
		{
			this.command = new GetStudentGroupCommand();
		}
	};
	
	ActionCommand command;
	
	public ActionCommand getCurrentCommand() {
		return command;
	}
}
