package ru.rsreu.studentsregistration.command;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;
import ru.rsreu.studentsregistration.resources.MessageManager;

public abstract class ActionCommand {
	private String page = null;
	private String url = null;
	private User current = null;

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public User getCurrent() {
		return current;
	}

	public void setCurrent(User current) {
		this.current = current;
	}

	public void executeCommand(HttpServletRequest request, HttpServletResponse response) {
		if (request.getSession() != null && request.getSession().getAttribute("current") != null) {
			current = (User) request.getSession().getAttribute("current");
		}
		request.setAttribute("current", current);
		try {
			execute(request, response);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			request.setAttribute("nullPage", MessageManager.getProperty("message.nullpage"));
			page = ConfigurationManager.getProperty("path.page.error");
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("nullPage", MessageManager.getProperty("message.nullpage"));
			page = ConfigurationManager.getProperty("path.page.error");
		}
	}

	public abstract void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException;

}
