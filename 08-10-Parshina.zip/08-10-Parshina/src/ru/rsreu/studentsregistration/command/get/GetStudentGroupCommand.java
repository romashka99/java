package ru.rsreu.studentsregistration.command.get;

import java.io.OutputStreamWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonWriter;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.StudentDAO;
import ru.rsreu.studentsregistration.dao.data.Student;

public class GetStudentGroupCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		int idType = Integer.parseInt(request.getParameter("type"));
		int idGroup = Integer.parseInt(request.getParameter("group"));
		DAOFactory factory = DAOFactory.getInstance();
		StudentDAO studentdao = factory.getStudentDAO();
		if (idType == 2) {
			
		}
		List<Student> students = studentdao.getGroupStudents(idGroup);
		if (students != null && !students.isEmpty()) {
			try {
				JsonWriter jsonWriter = new JsonWriter(new OutputStreamWriter(response.getOutputStream(), "UTF-8"));
				jsonWriter.setIndent("  ");
				jsonWriter.beginArray();
				for (Student student : students) {
					Gson gson = new GsonBuilder().create();
					gson.toJson(student, Student.class, jsonWriter);
				}
				jsonWriter.endArray();
				jsonWriter.close();
			} catch (Exception e) {

			}
		}

	}

}
