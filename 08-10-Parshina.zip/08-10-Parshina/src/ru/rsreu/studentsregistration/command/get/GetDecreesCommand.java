package ru.rsreu.studentsregistration.command.get;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.DecreeDAO;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.dao.data.UserRoleEnum;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetDecreesCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		User current = super.getCurrent();
		DAOFactory factory = DAOFactory.getInstance();
		DecreeDAO decreedao = factory.getDecreeDAO();
		if (current.getGroup().getRole() == UserRoleEnum.DEVELOPER) {
			int idUniversity = current.getUniversity().getId();
			request.setAttribute("decrees", decreedao.getUniversityDecrees(idUniversity));
		}
		super.setPage(ConfigurationManager.getProperty("path.page.decrees"));
	}

}
