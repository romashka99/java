package ru.rsreu.studentsregistration.command.get;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetUsersCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		DAOFactory factory = DAOFactory.getInstance();
		UserDAO userdao = factory.getUserDAO();
		request.setAttribute("users", userdao.getUsers());
		super.setPage(ConfigurationManager.getProperty("path.page.users"));
	}

}
