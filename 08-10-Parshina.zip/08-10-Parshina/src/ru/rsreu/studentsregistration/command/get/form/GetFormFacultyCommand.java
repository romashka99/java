package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.FacultyDAO;
import ru.rsreu.studentsregistration.dao.UniversityDAO;
import ru.rsreu.studentsregistration.dao.data.Faculty;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormFacultyCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		UniversityDAO universitydao = factory.getUniversityDAO();
		FacultyDAO facultydao = factory.getFacultyDAO();
		Faculty faculty = null;
		if (id > 0) {
			faculty = facultydao.getFacultyById(id);
		}
		request.setAttribute("faculty", faculty);
		request.setAttribute("universities", universitydao.getUniversities());
		super.setPage(ConfigurationManager.getProperty("path.page.form.faculty"));
	}

}
