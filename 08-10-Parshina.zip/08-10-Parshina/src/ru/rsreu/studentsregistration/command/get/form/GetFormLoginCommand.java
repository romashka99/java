package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormLoginCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		super.setPage(ConfigurationManager.getProperty("path.page.login"));
	}

}
