package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.EducationLevelDAO;
import ru.rsreu.studentsregistration.dao.SpecialtyDAO;
import ru.rsreu.studentsregistration.dao.data.Specialty;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormSpecialtyCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		EducationLevelDAO leveldao = factory.getEducationLevelDAO();
		SpecialtyDAO specialtydao = factory.getSpecialtyDAO();
		Specialty specialty = null;
		if (id > 0) {
			specialty = specialtydao.getSpecialtyById(id);
		}
		request.setAttribute("specialty", specialty);
		request.setAttribute("levels", leveldao.getEducationLevels());
		super.setPage(ConfigurationManager.getProperty("path.page.form.specialty"));
	}

}
