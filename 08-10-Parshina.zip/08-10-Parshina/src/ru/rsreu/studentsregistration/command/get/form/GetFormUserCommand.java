package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UniversityDAO;
import ru.rsreu.studentsregistration.dao.UserDAO;
import ru.rsreu.studentsregistration.dao.UserGroupDAO;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormUserCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		UserDAO userdao = factory.getUserDAO();
		UserGroupDAO usergroupdao = factory.getUserGroupDAO();
		UniversityDAO universitydao = factory.getUniversityDAO();
		User user = null;
		if (id > 0) {
			user = userdao.getUserById(id);
		}
		request.setAttribute("user", user);
		request.setAttribute("groups", usergroupdao.getUserGroups());
		request.setAttribute("universities", universitydao.getUniversities());
		super.setPage(ConfigurationManager.getProperty("path.page.form.user"));
	}

}
