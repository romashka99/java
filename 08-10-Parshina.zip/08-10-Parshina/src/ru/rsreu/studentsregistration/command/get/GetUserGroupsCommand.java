package ru.rsreu.studentsregistration.command.get;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserGroupDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetUserGroupsCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		DAOFactory factory = DAOFactory.getInstance();
		UserGroupDAO usergroupdao = factory.getUserGroupDAO();
		request.setAttribute("usergroups", usergroupdao.getUserGroups());
		super.setPage(ConfigurationManager.getProperty("path.page.usergroups"));
	}

}
