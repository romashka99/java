package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.StudentDAO;
import ru.rsreu.studentsregistration.dao.data.Student;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormStudentCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		StudentDAO studentdao = factory.getStudentDAO();
		Student student = null;
		if (id > 0) {
			student = studentdao.getStudentById(id);
		}
		request.setAttribute("student", student);
		super.setPage(ConfigurationManager.getProperty("path.page.form.student"));
	}

}
