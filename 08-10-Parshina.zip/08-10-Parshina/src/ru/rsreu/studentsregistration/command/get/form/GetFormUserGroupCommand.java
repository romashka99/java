package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserGroupDAO;
import ru.rsreu.studentsregistration.dao.data.UserGroup;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormUserGroupCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		UserGroupDAO usergroupdao = factory.getUserGroupDAO();
		UserGroup group = null;
		if (id > 0) {
			group = usergroupdao.getUserGroupById(id);
		}
		request.setAttribute("usergroup", group);
		super.setPage(ConfigurationManager.getProperty("path.page.form.usergroup"));
	}

}
