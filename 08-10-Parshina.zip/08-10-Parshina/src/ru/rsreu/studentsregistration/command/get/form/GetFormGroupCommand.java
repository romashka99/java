package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.DepartmentDAO;
import ru.rsreu.studentsregistration.dao.EducationFormDAO;
import ru.rsreu.studentsregistration.dao.GroupDAO;
import ru.rsreu.studentsregistration.dao.SpecialtyDAO;
import ru.rsreu.studentsregistration.dao.data.Group;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.dao.data.UserRoleEnum;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormGroupCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		User current = super.getCurrent();
		DepartmentDAO departmentdao = factory.getDepartmentDAO();
		EducationFormDAO formdao = factory.getEducationFormDAO();
		SpecialtyDAO specialtydao = factory.getSpecialtyDAO();
		GroupDAO groupdao = factory.getGroupDAO();
		Group group = null;
		if (id > 0) {
			group = groupdao.getGroupById(id);
		}
		request.setAttribute("group", group);
		if (current.getGroup().getRole() == UserRoleEnum.DEVELOPER) {
			request.setAttribute("departments",
					departmentdao.getUniversityDepartments(current.getUniversity().getId()));
		}
		if (current.getGroup().getRole() == UserRoleEnum.MODERATOR) {
			request.setAttribute("departments", departmentdao.getDepartments());
		}
		request.setAttribute("forms", formdao.getEducationForms());
		request.setAttribute("specialties", specialtydao.getSpecialties());
		super.setPage(ConfigurationManager.getProperty("path.page.form.group"));
	}

}
