package ru.rsreu.studentsregistration.command.get.form;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.DecreeDAO;
import ru.rsreu.studentsregistration.dao.DecreeTypeDAO;
import ru.rsreu.studentsregistration.dao.GroupDAO;
import ru.rsreu.studentsregistration.dao.data.Decree;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.dao.data.UserRoleEnum;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetFormDecreeCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String paramId = request.getParameter("id");
		int id = 0;
		if (paramId != null) {
			id = Integer.parseInt(paramId);
		}
		DAOFactory factory = DAOFactory.getInstance();
		User current = super.getCurrent();
		DecreeDAO decreedao = factory.getDecreeDAO();
		GroupDAO groupdao = factory.getGroupDAO();
		DecreeTypeDAO decreetypedao = factory.getDecreeTypeDAO();
		Decree decree = null;
		if (id > 0) {
			decree = decreedao.getDecreeById(id);
		}
		request.setAttribute("decree", decree);
		request.setAttribute("types", decreetypedao.getDecreeTypes());
		if (current.getGroup().getRole() == UserRoleEnum.DEVELOPER) {
			request.setAttribute("groups", groupdao.getUniversityGroups(current.getUniversity().getId()));
		}
		super.setPage(ConfigurationManager.getProperty("path.page.form.decree"));
	}

}
