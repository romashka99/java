package ru.rsreu.studentsregistration.command.get;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.DepartmentDAO;
import ru.rsreu.studentsregistration.dao.EducationFormDAO;
import ru.rsreu.studentsregistration.dao.EducationLevelDAO;
import ru.rsreu.studentsregistration.dao.FacultyDAO;
import ru.rsreu.studentsregistration.dao.GroupDAO;
import ru.rsreu.studentsregistration.dao.SpecialtyDAO;
import ru.rsreu.studentsregistration.dao.StudentDAO;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.dao.data.UserRoleEnum;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class GetInfosCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		User current = super.getCurrent();
		DAOFactory factory = DAOFactory.getInstance();
		FacultyDAO faculty = factory.getFacultyDAO();
		DepartmentDAO department = factory.getDepartmentDAO();
		GroupDAO group = factory.getGroupDAO();
		SpecialtyDAO specialty = factory.getSpecialtyDAO();
		EducationFormDAO form = factory.getEducationFormDAO();
		EducationLevelDAO level = factory.getEducationLevelDAO();
		StudentDAO student = factory.getStudentDAO();
		if (current.getGroup().getRole() == UserRoleEnum.MODERATOR) {
			request.setAttribute("faculties", faculty.getFaculties());
			request.setAttribute("departments", department.getDepartments());
			request.setAttribute("groups", group.getGroups());
			request.setAttribute("specialties", specialty.getSpecialties());
			request.setAttribute("forms", form.getEducationForms());
			request.setAttribute("levels", level.getEducationLevels());
			request.setAttribute("students", student.getStudents());
		}
		if (current.getGroup().getRole() == UserRoleEnum.DEVELOPER) {
			int idUniversity = current.getUniversity().getId();
			request.setAttribute("faculties", faculty.getUniversityFaculties(idUniversity));
			request.setAttribute("departments", department.getUniversityDepartments(idUniversity));
			request.setAttribute("groups", group.getUniversityGroups(idUniversity));
		}
		super.setPage(ConfigurationManager.getProperty("path.page.infos"));
	}

}
