package ru.rsreu.studentsregistration.command;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserDAO;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;
import ru.rsreu.studentsregistration.resources.MessageManager;

public class LoginCommand extends ActionCommand {
	private static final String PARAM_NAME_LOGIN = "login";
	private static final String PARAM_NAME_PASSWORD = "password";

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String login = request.getParameter(PARAM_NAME_LOGIN);
		String pass = request.getParameter(PARAM_NAME_PASSWORD);
		User user = null;
		DAOFactory factory = DAOFactory.getInstance();
		UserDAO dao = factory.getUserDAO();
		user = dao.getUserByLoginAndPassword(login, pass);
		if (user != null) {
			dao.loginUser(user.getId());
			request.getSession().setAttribute("current", user);
			request.getSession().setAttribute("login", user.getLogin());
			super.setUrl(user.GetMainCommand());
		} else {
			request.setAttribute("errorLoginPassMessage", MessageManager.getProperty("message.loginerror"));
			super.setPage(ConfigurationManager.getProperty("path.page.login"));
		}
	}

}
