package ru.rsreu.studentsregistration.command;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserDAO;
import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class EmptyCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		DAOFactory factory = DAOFactory.getInstance();
		UserDAO dao = factory.getUserDAO();
		User loginUser = dao.getLoginUser();
		if (loginUser != null) {
			super.setUrl(loginUser.GetMainCommand());
		}
		super.setUrl(ConfigurationManager.getProperty("url.get.form.login"));
	}

}
