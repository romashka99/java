package ru.rsreu.studentsregistration.command.add;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.DecreeDAO;
import ru.rsreu.studentsregistration.dao.StudentDAO;
import ru.rsreu.studentsregistration.dao.data.Student;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class AddDecreeCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String title = request.getParameter("title");
		int type = Integer.parseInt(request.getParameter("type"));
		int group = Integer.parseInt(request.getParameter("group"));
		String[] studentIds = request.getParameterValues("students");
		DAOFactory factory = DAOFactory.getInstance();
		StudentDAO studentdao = factory.getStudentDAO();
		List<Student> students = new ArrayList<Student>();
		if (studentIds != null) {
			for (String id : studentIds) {
				students.add(studentdao.getStudentById(Integer.parseInt(id)));
			}
		} else {
			String[] firstNames = request.getParameterValues("first-name");
			String[] secondNames = request.getParameterValues("second-name");
			String[] patronymics = request.getParameterValues("patronymic");
			String[] birthDates = request.getParameterValues("birth-date");
			String[] sexs = request.getParameterValues("sex");
			int length = firstNames.length;
			for (int i = 0; i < length; i++) {
				students.add(new Student(0, firstNames[i], secondNames[i], patronymics[i], sexs[i],
						Date.valueOf(birthDates[i]), null));
			}
		}
		if (type == 3) {
			group = Integer.parseInt(request.getParameter("group-to"));
		}
		DecreeDAO decree = factory.getDecreeDAO();
		decree.addDecree(title, new Date(Calendar.getInstance().getTime().getTime()), type, group, students);
		super.setUrl(ConfigurationManager.getProperty("url.get.decrees"));
	}

}
