package ru.rsreu.studentsregistration.command.add;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UniversityDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class AddUniversityCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String title = request.getParameter("title");
		String article = request.getParameter("article");
		String adress = request.getParameter("adress");
		DAOFactory factory = DAOFactory.getInstance();
		UniversityDAO dao = factory.getUniversityDAO();
		dao.addUniversity(title, article, adress);
		super.setUrl(ConfigurationManager.getProperty("url.get.universities"));
	}

}
