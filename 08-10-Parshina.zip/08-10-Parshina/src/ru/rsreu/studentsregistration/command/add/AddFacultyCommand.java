package ru.rsreu.studentsregistration.command.add;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.FacultyDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class AddFacultyCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String title = request.getParameter("title");
		String article = request.getParameter("article");
		int idUniversity = Integer.parseInt(request.getParameter("university"));
		DAOFactory factory = DAOFactory.getInstance();
		FacultyDAO dao = factory.getFacultyDAO();
		dao.addFaculty(title, article, idUniversity);
		super.setUrl(ConfigurationManager.getProperty("url.get.infos"));
	}

}
