package ru.rsreu.studentsregistration.command.add;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.DepartmentDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class AddDepartmentCommad extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String title = request.getParameter("title");
		String article = request.getParameter("article");
		int idFaculty = Integer.parseInt(request.getParameter("faculty"));
		DAOFactory factory = DAOFactory.getInstance();
		DepartmentDAO dao = factory.getDepartmentDAO();
		dao.addDepartment(title, article, idFaculty);
		super.setUrl(ConfigurationManager.getProperty("url.get.infos"));
	}

}
