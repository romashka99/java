package ru.rsreu.studentsregistration.command.add;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UserDAO;
import ru.rsreu.studentsregistration.dao.UserGroupDAO;
import ru.rsreu.studentsregistration.dao.data.UserGroup;
import ru.rsreu.studentsregistration.dao.data.UserRoleEnum;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class AddUserCommand extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String name = request.getParameter("name");
		String login = request.getParameter("login");
		String password = request.getParameter("password");
		int idGroup = Integer.parseInt(request.getParameter("group"));
		int idUniversity = Integer.parseInt(request.getParameter("university"));
		DAOFactory factory = DAOFactory.getInstance();
		UserDAO dao = factory.getUserDAO();
		UserGroupDAO usergroup = factory.getUserGroupDAO();
		UserGroup group = usergroup.getUserGroupById(idGroup);
		if (group.getRole() == UserRoleEnum.DEVELOPER) {
			dao.addUser(name, login, password, idGroup, idUniversity);
		} else {
			dao.addUser(name, login, password, idGroup);
		}
		super.setUrl(ConfigurationManager.getProperty("url.get.users"));
	}

}
