package ru.rsreu.studentsregistration.command.add;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.EducationLevelDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

public class AddEducationLevelCommad extends ActionCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ClassNotFoundException, SQLException {
		String title = request.getParameter("title");
		DAOFactory factory = DAOFactory.getInstance();
		EducationLevelDAO dao = factory.getEducationLevelDAO();
		dao.addEducationLevel(title);
		super.setUrl(ConfigurationManager.getProperty("url.get.infos"));
	}

}
