package ru.rsreu.studentsregistration;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ru.rsreu.studentsregistration.command.ActionCommand;
import ru.rsreu.studentsregistration.command.factory.ActionFactory;

/**
 * Request controller
 */
@WebServlet("/controller")
public class Controller extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
	}

	/**
	 * Handles a Get request
	 * 
	 * @param request  is a client request
	 * @param response is a response to the client
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Handles a Post request
	 * 
	 * @param request  is a client request
	 * @param response is a response to the client
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Processes the request
	 * 
	 * @param request is a client request
	 * @param response is a response to the client
	 * @throws ServletException is an exception class
	 * @throws IOException is an exception class
	 * @see HttpServlet#processRequest(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	private void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ActionFactory client = new ActionFactory();
		ActionCommand command = client.defineCommand(request);
		command.executeCommand(request, response);
		if (command.getPage() != null) {
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(command.getPage());
			dispatcher.forward(request, response);
		}
		if (command.getUrl() != null) {
			String url = request.getContextPath() + command.getUrl();
			response.sendRedirect(url);
		}
	}

}
