package ru.rsreu.studentsregistration.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ru.rsreu.studentsregistration.resources.ConfigurationManager;

@WebFilter("/controller")
public class LoginFilter implements Filter {

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest requestServlet, ServletResponse responceServlet, FilterChain chain)
			throws IOException, ServletException {
		boolean isRedirect = false;
		HttpServletRequest request = (HttpServletRequest) requestServlet;
		HttpServletResponse response = (HttpServletResponse) responceServlet;
		HttpSession session = request.getSession(false);
		if (!request.getParameter("command").equals("login") && !request.getParameter("command").equals("logout")
				&& !request.getParameter("command").equals("get_form_login")) {
			if (session != null) {
				String name = (String) session.getAttribute("login");
				if (name == null) {
					isRedirect = true;
				}
			} else {
				isRedirect = true;
			}
			if (isRedirect) {
				String url = request.getContextPath() + ConfigurationManager.getProperty("url.get.form.login");
				response.sendRedirect(url);
				return;
			}
		}
		chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig fConfig) throws ServletException {

	}

}
