package ru.rsreu.studentsregistration.resources;
import java.util.ResourceBundle;

public class ConfigurationManager {
	private final static ResourceBundle resourceBundle = ResourceBundle.getBundle("ru.rsreu.studentsregistration.resources.config");
	
	private ConfigurationManager() {
		
	}
	
	public static String getProperty(String key) {
		return resourceBundle.getString(key);
	}
}
