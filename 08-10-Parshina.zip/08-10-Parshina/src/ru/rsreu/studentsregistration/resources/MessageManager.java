package ru.rsreu.studentsregistration.resources;
import java.util.ResourceBundle;

public class MessageManager {
	private final static ResourceBundle resourceBundle = ResourceBundle.getBundle("ru.rsreu.studentsregistration.resources.messages");
	
	private MessageManager() { 
		
	}
	
	public static String getProperty(String key) {
		return resourceBundle.getString(key);
	}
}
