package ru.rsreu.studentsregistration.resources;

import java.util.ResourceBundle;

public class QueriesManager {
	private final static ResourceBundle resourceBundle = ResourceBundle.getBundle("ru.rsreu.studentsregistration.resources.queries");
	
	private QueriesManager() { 
		
	}
	
	public static String getString(String key) {
		return resourceBundle.getString(key);
	}
}
