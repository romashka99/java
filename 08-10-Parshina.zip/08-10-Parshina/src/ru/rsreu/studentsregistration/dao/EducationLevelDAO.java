package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.EducationLevel;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity decree's education
 * level
 * 
 * @author Parshina Anna
 *
 */
public class EducationLevelDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public EducationLevelDAO(Connection connection) {
		EducationLevelDAO.connection = connection;
	}

	/**
	 * Method for get education level by id
	 * 
	 * @param id - education level's identity
	 * @return education level
	 * @throws SQLException is an exception sql
	 */
	public EducationLevel getEducationLevelById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationLevel.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		EducationLevel level = null;
		while (result.next()) {
			String title = result.getString(2);
			level = new EducationLevel(id, title);
		}
		result.close();
		statement.close();
		return level;
	}

	/**
	 * Method for get all education levels
	 * 
	 * @return education levels
	 * @throws SQLException is an exception sql
	 */
	public List<EducationLevel> getEducationLevels() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationLevel.get.all"));
		ResultSet result = statement.executeQuery();
		List<EducationLevel> levels = new ArrayList<EducationLevel>();
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			levels.add(new EducationLevel(id, title));
		}
		result.close();
		statement.close();
		return levels;
	}

	/**
	 * Method for update education level
	 * 
	 * @param id    - education level's identity
	 * @param title - education level's title
	 * @throws SQLException is an exception sql
	 */
	public void updateEducationLevel(int id, String title) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationLevel.update"));
		statement.setString(1, title);
		statement.setInt(2, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add education level
	 * 
	 * @param title - education level's title
	 * @throws SQLException is an exception sql
	 */
	public void addEducationLevel(String title) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationLevel.add"));
		statement.setString(1, title);
		statement.executeUpdate();
	}

	/**
	 * Method for update education level
	 * 
	 * @param id - education level's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteEducationLevel(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationLevel.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
