package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.Specialty;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity specialty
 * 
 * @author Parshina Anna
 *
 */
public class SpecialtyDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public SpecialtyDAO(Connection connection) {
		SpecialtyDAO.connection = connection;
	}

	/**
	 * Method for get specialty by id
	 * 
	 * @param id - specialty's identity
	 * @return specialty
	 * @throws SQLException is an exception sql
	 */
	public Specialty getSpecialtyById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.specialty.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		Specialty specialty = null;
		EducationLevelDAO level = new EducationLevelDAO(connection);
		while (result.next()) {
			String code = result.getString(2);
			String title = result.getString(3);
			int period = result.getInt(4);
			int idLevel = result.getInt(5);
			specialty = new Specialty(id, code, title, period, level.getEducationLevelById(idLevel));
		}
		result.close();
		statement.close();
		return specialty;
	}

	/**
	 * Method for get all specialties
	 * 
	 * @return specialties
	 * @throws SQLException is an exception sql
	 */
	public List<Specialty> getSpecialties() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.specialty.get.all"));
		ResultSet result = statement.executeQuery();
		List<Specialty> specialties = new ArrayList<Specialty>();
		EducationLevelDAO level = new EducationLevelDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String code = result.getString(2);
			String title = result.getString(3);
			int period = result.getInt(4);
			int idLevel = result.getInt(5);
			specialties.add(new Specialty(id, code, title, period, level.getEducationLevelById(idLevel)));
		}
		result.close();
		statement.close();
		return specialties;
	}

	/**
	 * Method for update specialty
	 * 
	 * @param id      - specialty's identity
	 * @param code    - specialty's code
	 * @param title   - specialty's title
	 * @param period  - specialty's period
	 * @param idLevel - education level's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateSpecialty(int id, String code, String title, int period, int idLevel) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.specialty.update"));
		statement.setString(1, code);
		statement.setString(2, title);
		statement.setInt(3, period);
		statement.setInt(4, idLevel);
		statement.setInt(5, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add specialty
	 * 
	 * @param code    - specialty's code
	 * @param title   - specialty's title
	 * @param period  - specialty's period
	 * @param idLevel - education level's identity
	 * @throws SQLException is an exception sql
	 */
	public void addSpecialty(String code, String title, int period, int idLevel) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.specialty.add"));
		statement.setString(1, code);
		statement.setString(2, title);
		statement.setInt(3, period);
		statement.setInt(4, idLevel);
		statement.executeUpdate();
	}

	/**
	 * Method for delete specialty
	 * 
	 * @param id - specialty's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteSpecialty(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.specialty.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
