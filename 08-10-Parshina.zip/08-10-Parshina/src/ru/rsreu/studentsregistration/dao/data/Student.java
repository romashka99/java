package ru.rsreu.studentsregistration.dao.data;

import java.sql.Date;
/**
 * Class is a student entity that is needed to store data from a database 
 * @author Parshina Anna
 *
 */
public class Student {
	/**
	 * Student's identity
	 */
	private int id;
	/**
	 * Student's first name
	 */
	private String firstName;
	/**
	 * Student's second name
	 */
	private String secondName;
	/**
	 * Student's patronymic
	 */
	private String patronymic;
	/**
	 * Student's sex
	 */
	private String sex;
	/**
	 * Student's birth date
	 */
	private Date birthDate;
	/**
	 * Student's group
	 */
	private Group group;
	
	/**
	 * Default constructor
	 */
	public Student() {
		
	}

	/**
	 * Constructor with parameters
	 * @param id - student's identity
	 * @param firstName - student's first name
	 * @param secondName - student's second name
	 * @param patronymic - student's patronymic
	 * @param sex - student's sex
	 * @param birthDate - student's birth date
	 * @param group - student's group
	 */
	public Student(int id, String firstName, String secondName, String patronymic, String sex, Date birthDate,
			Group group) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.secondName = secondName;
		this.patronymic = patronymic;
		this.sex = sex;
		this.birthDate = birthDate;
		this.group = group;
	}

	/**
	 * Method for get student's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set student's identity 
	 * @param id - student's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get student's first name
	 * @return first name 
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Method for set student's first name 
	 * @param first name - student's first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Method for get student's second name
	 * @return second name 
	 */
	public String getSecondName() {
		return secondName;
	}

	/**
	 * Method for set student's second name 
	 * @param second name - student's second name
	 */
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}

	/**
	 * Method for get student's patronymic
	 * @return patronymic 
	 */
	public String getPatronymic() {
		return patronymic;
	}

	/**
	 * Method for set student's patronymic 
	 * @param patronymic - student's patronymic
	 */
	public void setPatronymic(String patronymic) {
		this.patronymic = patronymic;
	}

	/**
	 * Method for get student's sex
	 * @return sex 
	 */
	public String getSex() {
		return sex;
	}
	
	/**
	 * Method for set student's sex 
	 * @param sex - student's sex
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	/**
	 * Method for get student's string sex
	 */
	public String getSexString() {
		String sex = "";
		if(this.sex.contains("�")) {
			return "�������";
		}
		if(this.sex.contains("�")) {
			return "�������";
		}
		return sex;
	}

	/**
	 * Method for get student's birth date
	 * @return birth date 
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Method for set student's birth date 
	 * @param birth date - student's birth date
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Method for get student's group
	 * @return group 
	 */
	public Group getGroup() {
		return group;
	}

	/**
	 * Method for set student's group 
	 * @param group - student's group
	 */
	public void setGroup(Group group) {
		this.group = group;
	}
	
	/**
	 * Method for get student's full name
	 * @return full name 
	 */
	public String getFullName() {
		return String.format("%s %s %s", firstName, secondName, patronymic);
	}
}
