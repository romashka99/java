package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a education level entity that is needed to store data from a database
 * @author Parshina Anna
 *
 */
public class EducationLevel {
	/**
	 * Education level's identity
	 */
	private int id;
	/**
	 * Education level's title
	 */
	private String title;
	
	/**
	 * Default constructor
	 */
	public EducationLevel() {
		
	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id - education level's identity
	 * @param title - education level's title
	 */
	public EducationLevel(int id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	/**
	 * Method for get education level's identity
	 * @return identity
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set education level's identity
	 * @param id - education level's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get education level's title
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set education level's title
	 * @param title - education level's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
}
