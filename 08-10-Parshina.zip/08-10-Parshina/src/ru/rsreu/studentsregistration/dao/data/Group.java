package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a group entity that is needed to store data from a database 
 * @author Parshina Anna
 *
 */
public class Group {
	/**
	 * Group's identity
	 */
	private int id;
	/**
	 * Group's code
	 */
	private String code;
	/**
	 * Group's department
	 */
	private Department department;
	/**
	 * Group's specialty
	 */
	private Specialty specialty;
	/**
	 * Group's education form
	 */
	private EducationForm form;
	
	/**
	 * Default constructor
	 */
	public Group() {
		
	}

	/**
	 * Constructor with parameters
	 * @param id - group's identity
	 * @param code - group's code
	 * @param department - group's department
	 * @param specialty - group's specialty
	 * @param form - group's education form
	 */
	public Group(int id, String code, Department department, Specialty specialty, EducationForm form) {
		super();
		this.id = id;
		this.code = code;
		this.department = department;
		this.specialty = specialty;
		this.form = form;
	}

	/**
	 * Method for get group's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set group's identity 
	 * @param id - group's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get group's code
	 * @return code 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Method for set group's code 
	 * @param code - group's code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Method for get group's department
	 * @return department 
	 */
	public Department getDepartment() {
		return department;
	}

	/**
	 * Method for set group's department 
	 * @param department - group's department
	 */
	public void setDepartment(Department department) {
		this.department = department;
	}

	/**
	 * Method for get group's specialty
	 * @return specialty 
	 */
	public Specialty getSpecialty() {
		return specialty;
	}
	
	/**
	 * Method for set group's specialty 
	 * @param specialty - group's specialty
	 */
	public void setSpecialty(Specialty specialty) {
		this.specialty = specialty;
	}

	/**
	 * Method for get group's education form
	 * @return education form 
	 */
	public EducationForm getForm() {
		return form;
	}

	/**
	 * Method for set group's education form 
	 * @param education form - group's education form
	 */
	public void setForm(EducationForm form) {
		this.form = form;
	}
}
