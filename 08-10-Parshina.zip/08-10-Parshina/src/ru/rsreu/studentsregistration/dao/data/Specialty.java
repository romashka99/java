package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a specialty entity that is needed to store data from a database 
 * @author Parshina Anna
 *
 */
public class Specialty {
	/**
	 * Group's identity
	 */
	private int id;
	/**
	 * Group's code
	 */
	private String code;
	/**
	 * Group's title
	 */
	private String title;
	/**
	 * Group's period
	 */
	private int period;
	/**
	 * Group's education level
	 */
	private EducationLevel level;
	
	/**
	 * Default constructor
	 */
	public Specialty() {
		
	}

	/**
	 * Constructor with parameters
	 * @param id - specialty's identity
	 * @param code - specialty's code
	 * @param title - specialty's title
	 * @param period - specialty's period
	 * @param level - specialty's education level
	 */
	public Specialty(int id, String code, String title, int period, EducationLevel level) {
		super();
		this.id = id;
		this.code = code;
		this.title = title;
		this.period = period;
		this.level = level;
	}

	/**
	 * Method for get specialty's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set specialty's identity 
	 * @param id - specialty's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get specialty's code
	 * @return code 
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Method for set specialty's code 
	 * @param code - specialty's code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Method for get specialty's title
	 * @return title 
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set specialty's title
	 * @param title - specialty's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Method for get specialty's period
	 * @return period 
	 */
	public int getPeriod() {
		return period;
	}

	/**
	 * Method for set specialty's period
	 * @param period - specialty's period
	 */
	public void setPeriod(int period) {
		this.period = period;
	}

	/**
	 * Method for get specialty's level
	 * @return level 
	 */
	public EducationLevel getLevel() {
		return level;
	}

	/**
	 * Method for set specialty's level
	 * @param level - specialty's level
	 */
	public void setLevel(EducationLevel level) {
		this.level = level;
	}
}
