package ru.rsreu.studentsregistration.dao.data;

/**
 * Class is a user's group entity that is needed to store data from a database
 * @author Parshina Anna
 *
 */
public class UserGroup {
	/**
	 * User group's type identity
	 */
	private int id;
	/**
	 * User group's type title
	 */
	private String title;
	
	/**
	 * Default constructor
	 */
	public UserGroup() {
		
	}
	
	/**
	 * Constructor with parameters
	 * 
	 * @param id - user group's identity
	 * @param title - user group's title
	 */
	public UserGroup(int id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	/**
	 * Method for get user group's identity
	 * @return identity
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set user group's identity
	 * @param id - user group's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get user group's title
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set user group's title
	 * @param title - user group's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * Method for get user group's role
	 * @return user group's role
	 */
	public UserRoleEnum getRole() {
		UserRoleEnum role = null;
		if (title.contains("�������������")) {
			role = UserRoleEnum.ADMIN;
		}
		if (title.contains("���������")) {
			role = UserRoleEnum.MODERATOR;
		}
		if (title.contains("���������")) {
			role = UserRoleEnum.DEVELOPER;
		}
		return role;
	}
}