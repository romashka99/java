package ru.rsreu.studentsregistration.dao.data;

import java.sql.SQLException;

import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.UniversityDAO;
import ru.rsreu.studentsregistration.resources.ConfigurationManager;

/**
 * Class is a user entity that is needed to store data from a database
 * 
 * @author Parshina Anna
 *
 */
public class User {
	/**
	 * User's identity
	 */
	private int id;
	/**
	 * User's full name
	 */
	private String fullName;
	/**
	 * User's login
	 */
	private String login;
	/**
	 * User's password
	 */
	private String password;
	/**
	 * User's online
	 */
	private boolean isOnline;
	/**
	 * User's group
	 */
	private UserGroup group;

	/**
	 * Default constructor
	 */
	public User() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id       - user's identity
	 * @param fullName - user's full name
	 * @param login    - user's login
	 * @param password - user's password
	 * @param isOnline - user's online
	 * @param group    - user's group
	 */
	public User(int id, String fullName, String login, String password, int isOnline, UserGroup group) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.login = login;
		this.password = password;
		setOnline(isOnline);
		this.group = group;
	}

	/**
	 * Method for get user's identity
	 * 
	 * @return identity
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set user's identity
	 * 
	 * @param id - user's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get user's full name
	 * 
	 * @return full name
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * Method for set user's full name
	 * 
	 * @param fullName - user's full name
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	/**
	 * Method for get user's login
	 * 
	 * @return login
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * Method for set user's login
	 * 
	 * @param login - user's login
	 */
	public void setLogin(String login) {
		this.login = login;
	}

	/**
	 * Method for get user's password
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Method for set user's password
	 * 
	 * @param password - user's password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Method for get user's online
	 * 
	 * @return online
	 */
	public boolean isOnline() {
		return isOnline;
	}

	/**
	 * Method for set user's online
	 * 
	 * @param isOnline - true - online, false - offline
	 */
	public void setOnline(boolean isOnline) {
		this.isOnline = isOnline;
	}

	/**
	 * Method for set user's online
	 * 
	 * @param isOnline - 1 - online, 0 - offline
	 */
	public void setOnline(int isOnline) {
		if (isOnline == 0) {
			this.isOnline = false;
		}
		if (isOnline == 1) {
			this.isOnline = true;
		}
	}

	/**
	 * Method for get user's group
	 * 
	 * @return group
	 */
	public UserGroup getGroup() {
		return group;
	}

	/**
	 * Method for set user's group
	 * 
	 * @param group - user's group
	 */
	public void setGroup(UserGroup group) {
		this.group = group;
	}

	/**
	 * Method for get user's main command
	 * 
	 * @return url main command
	 */
	public String GetMainCommand() {
		String result = "";
		if (group.getTitle().contains("���������")) {
			result = ConfigurationManager.getProperty("url.get.infos");
		}
		if (group.getTitle().contains("�������������")) {
			result = ConfigurationManager.getProperty("url.get.users");
		}
		if (group.getTitle().contains("���������")) {
			result = ConfigurationManager.getProperty("url.get.decrees");
		}
		return result;
	}

	/**
	 * Method for get user's university
	 * 
	 * @return university
	 */
	public University getUniversity() {
		University university = null;
		try {
			DAOFactory factory = DAOFactory.getInstance();
			UniversityDAO dao = factory.getUniversityDAO();
			university = dao.getUserUniversity(this.id);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return university;
	}
}
