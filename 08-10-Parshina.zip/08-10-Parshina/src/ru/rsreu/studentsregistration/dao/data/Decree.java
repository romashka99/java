package ru.rsreu.studentsregistration.dao.data;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import ru.rsreu.studentsregistration.dao.DAOFactory;
import ru.rsreu.studentsregistration.dao.StudentDAO;

/**
 * Class is a decree entity that is needed to store data from a database
 * @author Parshina Anna
 *
 */
public class Decree {
	/**
	 * Decree's identity
	 */
	private int id;
	/**
	 * Decree's title
	 */
	private String title;
	/**
	 * Decree's open date
	 */
	private Date openDate;
	/**
	 * Decree is signed
	 */
	private boolean isSigned;
	/**
	 * Decree's type
	 */
	private DecreeType type;
	/**
	 * Decree's group
	 */
	private Group group;
	
	/**
	 * Default constructor
	 */
	public Decree() {
		
	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id - decree's identity
	 * @param title - decree's title
	 * @param openDate - decree's open date
	 * @param isSigned - decree's signed
	 * @param type - decree's type
	 * @param group - decree's group
	 */
	public Decree(int id, String title, Date openDate, int isSigned, DecreeType type, Group group) {
		super();
		this.id = id;
		this.title = title;
		this.openDate = openDate;
		setSigned(isSigned);
		this.type = type;
		this.group = group;
	}

	/**
	 * Method for get decree's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set decree's identity 
	 * @param id - identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get decree's title
	 * @return title 
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set decree's title
	 * @param title - decree's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Method for get decree's open date
	 * @return open date 
	 */
	public Date getOpenDate() {
		return openDate;
	}

	/**
	 * Method for set decree's open date
	 * @param title - decree's open date
	 */
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	/**
	 * Method for get decree signed
	 * @return signed 
	 */
	public boolean isSigned() {
		return isSigned;
	}

	/**
	 * Method for set signed decree 
	 * @param isSigned - true - signed, false - don't signed
	 */
	public void setSigned(boolean isSigned) {
		this.isSigned = isSigned;
	}
	
	/**
	 * Method for set decree signed
	 * @param isSigned - 0 - don't signed, 1 - signed
	 */
	public void setSigned(int isSigned) {
		if(isSigned == 0) {
			this.isSigned = false;
		}
		if(isSigned == 1) {
			this.isSigned = true;
		}
	}

	/**
	 * Method for get decree's type
	 * @return type 
	 */
	public DecreeType getType() {
		return type;
	}

	/**
	 * Method for set decree's type
	 * @param type - decree's type 
	 */
	public void setType(DecreeType type) {
		this.type = type;
	}
	
	/**
	 * Method for get decree's students
	 * @return students 
	 */
	public List<Student> getStudents() {
		List<Student> students = null;
		try {
			DAOFactory factory = DAOFactory.getInstance();
			StudentDAO dao = factory.getStudentDAO();
			students = dao.getDecreeStudents(this.id);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return students;
	}
	
	/**
	 * Method for get decree's status
	 * @return status 
	 */
	public String getStatus() {
		String result = "�� ��������";
		if (isSigned) {
			result = "��������";
		}
		return result;
	}
	
	/**
	 * Method for get decree's group
	 * @return group 
	 */
	public Group getGroup() {
		return group;
	}

	/**
	 * Method for set decree's group
	 * @param group - group
	 */
	public void setGroup(Group group) {
		this.group = group;
	}
}