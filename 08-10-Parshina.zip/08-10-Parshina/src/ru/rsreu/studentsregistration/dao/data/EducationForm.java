package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a education form entity that is needed to store data from a database
 * @author Parshina Anna
 *
 */
public class EducationForm {
	/**
	 * Education form's identity
	 */
	private int id;
	/**
	 * Education form's title
	 */
	private String title;
	
	/**
	 * Default constructor
	 */
	public EducationForm() {
		
	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id - education form's identity
	 * @param title - education form's title
	 */
	public EducationForm(int id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	/**
	 * Method for get education form's identity
	 * @return identity
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set education form's identity
	 * @param id - education form's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get education form's title
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set education form's title
	 * @param title - education form's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
}
