package ru.rsreu.studentsregistration.dao.data;

/**
 * Class is a user group role
 * @author Parshina Anna
 *
 */
public enum UserRoleEnum {
	/**
	 * Administrator
	 */
	ADMIN,
	/**
	 * Developer
	 */
	DEVELOPER,
	/**
	 * Moderator
	 */
	MODERATOR
}
