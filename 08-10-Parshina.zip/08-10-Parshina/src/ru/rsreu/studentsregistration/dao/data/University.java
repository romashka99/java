package ru.rsreu.studentsregistration.dao.data;

import java.util.List;

/**
 * Class is a university entity that is needed to record loan data from a
 * database
 * 
 * @author Parshina Anna
 *
 */
public class University {
	/**
	 * University's identity
	 */
	private int id;
	/**
	 * University's title
	 */
	private String title;
	/**
	 * University's article
	 */
	private String article;
	/**
	 * University's adress
	 */
	private String adress;
	/**
	 * University's developers
	 */
	private List<User> users;

	/**
	 * Default constructor
	 */
	public University() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id      - university's identity
	 * @param title   - university's title
	 * @param article - university's article
	 */
	public University(int id, String title, String article) {
		super();
		this.id = id;
		this.title = title;
		this.article = article;
	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id      - university's identity
	 * @param title   - university's title
	 * @param article - university's article
	 * @param adress  - university's adress
	 * @param users   - university's developers
	 */
	public University(int id, String title, String article, String adress, List<User> users) {
		super();
		this.id = id;
		this.title = title;
		this.article = article;
		this.adress = adress;
		this.users = users;
	}
	
	/**
	 * Method for get university's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set university's identity
	 * 
	 * @param id - identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get university's title
	 * 
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set university's title
	 * 
	 * @param title - university's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Method for get university's article
	 * 
	 * @return article
	 */
	public String getArticle() {
		return article;
	}

	/**
	 * Method for set university's article
	 * 
	 * @param article - university's article
	 */
	public void setArticle(String article) {
		this.article = article;
	}

	/**
	 * Method for get university's adress
	 * 
	 * @return adress
	 */
	public String getAdress() {
		return adress;
	}

	/**
	 * Method for set university's adress
	 * 
	 * @param adress - university's adress
	 */
	public void setAdress(String adress) {
		this.adress = adress;
	}

	/**
	 * Method for get university's developers
	 * 
	 * @return users
	 */
	public List<User> getUsers() {
		return users;
	}

	/**
	 * Method for set university's developers
	 * 
	 * @param users - university's developers
	 */
	public void setUsers(List<User> users) {
		this.users = users;
	}

	/**
	 * Method for get university's names developers
	 * 
	 * @return names developers
	 */
	public String getNameUsers() {
		StringBuilder result = new StringBuilder();
		for (User user : users) {
			result.append(String.format("%s, ", user.getFullName()));
		}
		return result.toString();
	}

}
