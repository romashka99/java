package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a department entity that is needed to store data from a database 
 * @author Parshina Anna
 *
 */
public class Department {
	/**
	 * Department's identity
	 */
	private int id;
	/**
	 * Department's title
	 */
	private String title;
	/**
	 * Department's article
	 */
	private String article;
	/**
	 * Department's faculty
	 */
	private Faculty faculty;
	
	/**
	 * Default constructor
	 */
	public Department() {
		
	}

	/**
	 * Constructor with parameters
	 * @param id  - department's identity
	 * @param title  - department's title
	 * @param article  - department's article
	 * @param faculty  - department's faculty
	 */
	public Department(int id, String title, String article, Faculty faculty) {
		super();
		this.id = id;
		this.title = title;
		this.article = article;
		this.faculty = faculty;
	}

	/**
	 * Method for get department's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set department's identity 
	 * @param id - identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get department's title
	 * @return title 
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set department's title
	 * @param title - department's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Method for get department's article
	 * @return article 
	 */
	public String getArticle() {
		return article;
	}

	/**
	 * Method for set department's article
	 * @param article - department's article
	 */
	public void setArticle(String article) {
		this.article = article;
	}

	/**
	 * Method for get department's faculty
	 * @return faculty 
	 */
	public Faculty getFaculty() {
		return faculty;
	}

	/**
	 * Method for set department's faculty
	 * @param faculty - department's faculty
	 */
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	
}
