package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a decree's type entity that is needed to store data from a database
 * @author Parshina Anna
 *
 */
public class DecreeType {
	/**
	 * Decree's type identity
	 */
	private int id;
	/**
	 * Decree's type title
	 */
	private String title;
	
	/**
	 * Default constructor
	 */
	public DecreeType() {
		
	}

	/**
	 * Constructor with parameters
	 * 
	 * @param id - decree's type identity
	 * @param title - decree's type title
	 */
	public DecreeType(int id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	/**
	 * Method for get decree's type identity
	 * @return identity
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set decree's type identity
	 * @param id - decree's type identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get decree's type title
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set decree's type title
	 * @param title - decree's type title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
}
