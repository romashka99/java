package ru.rsreu.studentsregistration.dao.data;
/**
 * Class is a faculty entity that is needed to store data from a database 
 * @author Parshina Anna
 *
 */
public class Faculty {
	/**
	 * Faculty's identity
	 */
	private int id;
	/**
	 * Faculty's title
	 */
	private String title;
	/**
	 * Faculty's article
	 */
	private String article;
	/**
	 * Faculty's university
	 */
	private University university;
	
	/**
	 * Default constructor
	 */
	public Faculty() {
		
	}

	/**
	 * Constructor with parameters
	 * @param id  - faculty's identity
	 * @param title  - faculty's title
	 * @param article  - faculty's article
	 * @param university  - faculty's university
	 */
	public Faculty(int id, String title, String article, University university) {
		super();
		this.id = id;
		this.title = title;
		this.article = article;
		this.university = university;
	}

	/**
	 * Method for get faculty's identity
	 * @return identity 
	 */
	public int getId() {
		return id;
	}

	/**
	 * Method for set faculty's identity 
	 * @param id - faculty's identity
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Method for get faculty's title
	 * @return title 
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Method for set faculty's title
	 * @param title - faculty's title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Method for get faculty's article
	 * @return article 
	 */
	public String getArticle() {
		return article;
	}

	/**
	 * Method for set faculty's article
	 * @param article - faculty's article
	 */
	public void setArticle(String article) {
		this.article = article;
	}

	/**
	 * Method for get faculty's university
	 * @return university
	 */
	public University getUniversity() {
		return university;
	}

	/**
	 * Method for set faculty's university
	 * @param university - faculty's university
	 */
	public void setUniversity(University university) {
		this.university = university;
	}
}
