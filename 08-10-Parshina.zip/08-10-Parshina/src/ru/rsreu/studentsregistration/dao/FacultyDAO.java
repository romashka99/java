package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.Faculty;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity faculty
 * 
 * @author Parshina Anna
 *
 */
public class FacultyDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public FacultyDAO(Connection connection) {
		FacultyDAO.connection = connection;
	}

	/**
	 * Method for get faculty by id
	 * 
	 * @param id - faculty's identity
	 * @return faculty
	 * @throws SQLException is an exception sql
	 */
	public Faculty getFacultyById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.faculty.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		Faculty faculty = null;
		UniversityDAO university = new UniversityDAO(connection);
		while (result.next()) {
			String title = result.getString(2);
			String article = result.getString(3);
			int idUniversity = result.getInt(4);
			faculty = new Faculty(id, title, article, university.getUniversityById(idUniversity));
		}
		result.close();
		statement.close();
		return faculty;
	}

	/**
	 * Method for get all faculties
	 * 
	 * @return faculties
	 * @throws SQLException is an exception sql
	 */
	public List<Faculty> getFaculties() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.faculty.get.all"));
		ResultSet result = statement.executeQuery();
		List<Faculty> faculties = new ArrayList<Faculty>();
		UniversityDAO university = new UniversityDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			String article = result.getString(3);
			int idUniversity = result.getInt(4);
			faculties.add(new Faculty(id, title, article, university.getUniversityById(idUniversity)));
		}
		result.close();
		statement.close();
		return faculties;
	}

	/**
	 * Method for get university's faculties
	 * 
	 * @param idUniversity - university's identity
	 * @return faculties
	 * @throws SQLException is an exception sql
	 */
	public List<Faculty> getUniversityFaculties(int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.faculty.get.university"));
		statement.setInt(1, idUniversity);
		ResultSet result = statement.executeQuery();
		List<Faculty> faculties = new ArrayList<Faculty>();
		UniversityDAO university = new UniversityDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			String article = result.getString(3);
			faculties.add(new Faculty(id, title, article, university.getUniversityById(idUniversity)));
		}
		result.close();
		statement.close();
		return faculties;
	}

	/**
	 * Method for update faculty
	 * 
	 * @param id           - faculty's's identity
	 * @param title        - faculty's's title
	 * @param article      - faculty's's article
	 * @param idUniversity - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateFaculty(int id, String title, String article, int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.faculty.update"));
		statement.setString(1, title);
		statement.setString(2, article);
		statement.setInt(3, idUniversity);
		statement.setInt(4, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add faculty
	 * 
	 * @param title        - faculty's's title
	 * @param article      - faculty's's article
	 * @param idUniversity - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void addFaculty(String title, String article, int idUniversity) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.faculty.add"));
		statement.setString(1, title);
		statement.setString(2, article);
		statement.setInt(3, idUniversity);
		statement.executeUpdate();
	}

	/**
	 * Method for delete faculty
	 * 
	 * @param id - faculty's's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteFaculty(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.faculty.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
