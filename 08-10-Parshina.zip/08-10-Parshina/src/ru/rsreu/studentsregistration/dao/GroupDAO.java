package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.Group;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity group
 * 
 * @author Parshina Anna
 *
 */
public class GroupDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public GroupDAO(Connection connection) {
		GroupDAO.connection = connection;
	}

	/**
	 * Method for get group by id
	 * 
	 * @param id - group's identity
	 * @return group
	 * @throws SQLException is an exception sql
	 */
	public Group getGroupById(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.group.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		Group group = null;
		SpecialtyDAO specialty = new SpecialtyDAO(connection);
		DepartmentDAO department = new DepartmentDAO(connection);
		EducationFormDAO form = new EducationFormDAO(connection);
		while (result.next()) {
			String code = result.getString(2);
			int idForm = result.getInt(3);
			int idSpecialty = result.getInt(4);
			int idDepartment = result.getInt(5);
			group = new Group(id, code, department.getDepartmentById(idDepartment),
					specialty.getSpecialtyById(idSpecialty), form.getEducationFormById(idForm));
		}
		result.close();
		statement.close();
		return group;
	}

	/**
	 * Method for get all groups
	 * 
	 * @return groups
	 * @throws SQLException is an exception sql
	 */
	public List<Group> getGroups() throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.group.get.all"));
		ResultSet result = statement.executeQuery();
		List<Group> groups = new ArrayList<Group>();
		SpecialtyDAO specialty = new SpecialtyDAO(connection);
		DepartmentDAO department = new DepartmentDAO(connection);
		EducationFormDAO form = new EducationFormDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String code = result.getString(2);
			int idForm = result.getInt(3);
			int idSpecialty = result.getInt(4);
			int idDepartment = result.getInt(5);
			groups.add(new Group(id, code, department.getDepartmentById(idDepartment),
					specialty.getSpecialtyById(idSpecialty), form.getEducationFormById(idForm)));
		}
		result.close();
		statement.close();
		return groups;
	}

	/**
	 * Method for get university's groups
	 * 
	 * @param idUniversity - university's identity
	 * @return groups
	 * @throws SQLException is an exception sql
	 */
	public List<Group> getUniversityGroups(int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.group.get.university"));
		statement.setInt(1, idUniversity);
		ResultSet result = statement.executeQuery();
		List<Group> groups = new ArrayList<Group>();
		SpecialtyDAO specialty = new SpecialtyDAO(connection);
		DepartmentDAO department = new DepartmentDAO(connection);
		EducationFormDAO form = new EducationFormDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String code = result.getString(2);
			int idForm = result.getInt(3);
			int idSpecialty = result.getInt(4);
			int idDepartment = result.getInt(5);
			groups.add(new Group(id, code, department.getDepartmentById(idDepartment),
					specialty.getSpecialtyById(idSpecialty), form.getEducationFormById(idForm)));
		}
		result.close();
		statement.close();
		return groups;
	}

	/**
	 * Method for update group
	 * 
	 * @param id           - group's identity
	 * @param code         - group's code
	 * @param idForm       - form's identity
	 * @param idSpecialty  - specialty's identity
	 * @param idDepartment - department's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateGroup(int id, String code, int idForm, int idSpecialty, int idDepartment) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.group.update"));
		statement.setString(1, code);
		statement.setInt(2, idForm);
		statement.setInt(3, idSpecialty);
		statement.setInt(4, idDepartment);
		statement.setInt(5, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add group
	 * 
	 * @param code         - group's code
	 * @param idForm       - form's identity
	 * @param idSpecialty  - specialty's identity
	 * @param idDepartment - department's identity
	 * @throws SQLException is an exception sql
	 */
	public void addGroup(String code, int idForm, int idSpecialty, int idDepartment) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.group.add"));
		statement.setString(1, code);
		statement.setInt(2, idForm);
		statement.setInt(3, idSpecialty);
		statement.setInt(4, idDepartment);
		statement.executeUpdate();
	}

	/**
	 * Method for delete group
	 * 
	 * @param id - group's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteGroup(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.group.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
