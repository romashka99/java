package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.UserGroup;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity user's group
 * 
 * @author Parshina Anna
 *
 */
public class UserGroupDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public UserGroupDAO(Connection connection) {
		UserGroupDAO.connection = connection;
	}

	/**
	 * Method for get all user's groups
	 * 
	 * @return user's groups
	 * @throws SQLException is an exception sql
	 */
	public List<UserGroup> getUserGroups() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.userGroup.get.all"));
		ResultSet result = statement.executeQuery();
		List<UserGroup> groups = new ArrayList<UserGroup>();
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			groups.add(new UserGroup(id, title));
		}
		result.close();
		statement.close();
		return groups;
	}

	/**
	 * Method for get user's group by id
	 * 
	 * @param id - user group's identity
	 * @return user's group
	 * @throws SQLException is an exception sql
	 */
	public UserGroup getUserGroupById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.userGroup.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		UserGroup group = null;
		while (result.next()) {
			String title = result.getString(2);
			group = new UserGroup(id, title);
		}
		result.close();
		statement.close();
		return group;
	}

	/**
	 * Method for update user's group
	 * 
	 * @param id    - user group's identity
	 * @param title - user group's title
	 * @throws SQLException is an exception sql
	 */
	public void updateUserGroup(int id, String title) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.userGroup.update"));
		statement.setString(1, title);
		statement.setInt(2, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add user's group
	 * 
	 * @param title - user group's title
	 * @throws SQLException is an exception sql
	 */
	public void addUserGroup(String title) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.userGroup.add"));
		statement.setString(1, title);
		statement.executeUpdate();
	}

	/**
	 * Method for delete user's group
	 * 
	 * @param id - user group's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteUserGroup(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.userGroup.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}
}
