package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;

public class DAOFactory {
	private static volatile DAOFactory instance;
	private Connection connection;

	private DAOFactory() {
		
	}

	public static DAOFactory getInstance()
			throws ClassNotFoundException, SQLException {
		DAOFactory factory = instance;
		if (instance == null) {
			synchronized (DAOFactory.class) {
				factory = new DAOFactory();
				instance = factory;
				factory.connected();
			}
		}
		return factory;
	}

	private void connected() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Locale.setDefault(Locale.PRC);
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "ANNA";
		String password = "111";
		connection = DriverManager.getConnection(url, user, password);
	}
	
	public UserDAO getUserDAO() {
		return new UserDAO(connection);
	}
	
	public UserGroupDAO getUserGroupDAO() {
		return new UserGroupDAO(connection);
	}
	
	public UniversityDAO getUniversityDAO() {
		return new UniversityDAO(connection);
	}
	
	public FacultyDAO getFacultyDAO() {
		return new FacultyDAO(connection);
	}
	
	public DepartmentDAO getDepartmentDAO() {
		return new DepartmentDAO(connection);
	}
	
	public SpecialtyDAO getSpecialtyDAO() {
		return new SpecialtyDAO(connection);
	}
	
	public GroupDAO getGroupDAO() {
		return new GroupDAO(connection);
	}
	
	public EducationLevelDAO getEducationLevelDAO() {
		return new EducationLevelDAO(connection);
	}
	
	public EducationFormDAO getEducationFormDAO() {
		return new EducationFormDAO(connection);
	}
	
	public DecreeDAO getDecreeDAO() {
		return new DecreeDAO(connection);
	}
	
	public DecreeTypeDAO getDecreeTypeDAO() {
		return new DecreeTypeDAO(connection);
	}
	
	public StudentDAO getStudentDAO() {
		return new StudentDAO(connection);
	}


}
