package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.Department;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity department
 * 
 * @author Parshina Anna
 *
 */
public class DepartmentDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public DepartmentDAO(Connection connection) {
		DepartmentDAO.connection = connection;
	}

	/**
	 * Method for get department by id
	 * 
	 * @param id - department's identity
	 * @return department
	 * @throws SQLException is an exception sql
	 */
	public Department getDepartmentById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.department.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		Department department = null;
		FacultyDAO faculty = new FacultyDAO(connection);
		while (result.next()) {
			String title = result.getString(2);
			String article = result.getString(3);
			int idFaculty = result.getInt(4);
			department = new Department(id, title, article, faculty.getFacultyById(idFaculty));
		}
		result.close();
		statement.close();
		return department;
	}

	/**
	 * Method for get all departments
	 * 
	 * @return departments
	 * @throws SQLException is an exception sql
	 */
	public List<Department> getDepartments() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.department.get.all"));
		ResultSet result = statement.executeQuery();
		List<Department> departments = new ArrayList<Department>();
		FacultyDAO faculty = new FacultyDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			String article = result.getString(3);
			int idFaculty = result.getInt(4);
			departments.add(new Department(id, title, article, faculty.getFacultyById(idFaculty)));
		}
		result.close();
		statement.close();
		return departments;
	}

	/**
	 * Method for get university's department
	 * 
	 * @param id - university's identity
	 * @return departments
	 * @throws SQLException is an exception sql
	 */
	public List<Department> getUniversityDepartments(int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.department.get.university"));
		statement.setInt(1, idUniversity);
		ResultSet result = statement.executeQuery();
		List<Department> departments = new ArrayList<Department>();
		FacultyDAO faculty = new FacultyDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			String article = result.getString(3);
			int idFaculty = result.getInt(4);
			departments.add(new Department(id, title, article, faculty.getFacultyById(idFaculty)));
		}
		result.close();
		statement.close();
		return departments;
	}

	/**
	 * Method for get department's by id
	 * 
	 * @param id        - department's identity
	 * @param title     - department's title
	 * @param article   - department's article
	 * @param idFaculty - department's faculty identity
	 * @throws SQLException is an exception sql
	 */
	public void updateDepartment(int id, String title, String article, int idFaculty) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.department.update"));
		statement.setString(1, title);
		statement.setString(2, article);
		statement.setInt(3, idFaculty);
		statement.setInt(4, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add department
	 * 
	 * @param title     - department's title
	 * @param article   - department's article
	 * @param idFaculty - department's faculty identity
	 * @throws SQLException is an exception sql
	 */
	public void addDepartment(String title, String article, int idFaculty) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.department.add"));
		statement.setString(1, title);
		statement.setString(2, article);
		statement.setInt(3, idFaculty);
		statement.executeUpdate();
	}

	/**
	 * Method for delete department
	 * 
	 * @param title     - department's title
	 * @param article   - department's article
	 * @param idFaculty - department's faculty identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteDepartment(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.department.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
