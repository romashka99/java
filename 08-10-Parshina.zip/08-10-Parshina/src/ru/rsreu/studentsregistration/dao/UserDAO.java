package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.User;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity user
 * 
 * @author Parshina Anna
 *
 */
public class UserDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public UserDAO(Connection connection) {
		UserDAO.connection = connection;
	}

	/**
	 * Method for get user by id
	 * 
	 * @param id - user's identity
	 * @return user
	 * @throws SQLException is an exception sql
	 */
	public User getUserById(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		User user = null;
		UserGroupDAO groupDao = new UserGroupDAO(connection);
		while (result.next()) {
			String name = result.getString(2);
			String login = result.getString(3);
			String password = result.getString(4);
			int isOnline = result.getInt(5);
			int idGroup = result.getInt(6);
			user = new User(id, name, login, password, isOnline, groupDao.getUserGroupById(idGroup));
		}
		result.close();
		statement.close();
		return user;
	}

	/**
	 * Method for get login user
	 * 
	 * @return user
	 * @throws SQLException is an exception sql
	 */
	public User getLoginUser() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.user.get.one.login"));
		ResultSet result = statement.executeQuery();
		User user = null;
		UserGroupDAO groupDao = new UserGroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String name = result.getString(2);
			String login = result.getString(3);
			String password = result.getString(4);
			int isOnline = result.getInt(5);
			int idGroup = result.getInt(6);
			user = new User(id, name, login, password, isOnline, groupDao.getUserGroupById(idGroup));
		}
		result.close();
		statement.close();
		return user;
	}

	/**
	 * Method for get user by login and password
	 * 
	 * @param login    - user's login
	 * @param password - user's password
	 * @return user
	 * @throws SQLException is an exception sql
	 */
	public User getUserByLoginAndPassword(String login, String password) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.user.get.one.for.login"));
		statement.setString(1, login);
		statement.setString(2, password);
		ResultSet result = statement.executeQuery();
		User user = null;
		UserGroupDAO groupDao = new UserGroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String name = result.getString(2);
			int isOnline = result.getInt(5);
			int idGroup = result.getInt(6);
			user = new User(id, name, login, password, isOnline, groupDao.getUserGroupById(idGroup));
		}
		result.close();
		statement.close();
		return user;
	}

	/**
	 * Method for get all users
	 * 
	 * @return users
	 * @throws SQLException is an exception sql
	 */
	public List<User> getUsers() throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.get.all"));
		ResultSet result = statement.executeQuery();
		List<User> users = new ArrayList<User>();
		UserGroupDAO groupDao = new UserGroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String name = result.getString(2);
			String login = result.getString(3);
			String password = result.getString(4);
			int isOnline = result.getInt(5);
			int idGroup = result.getInt(6);
			users.add(new User(id, name, login, password, isOnline, groupDao.getUserGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return users;
	}

	/**
	 * Method for get university's user
	 * 
	 * @param idUniversity - university's identity
	 * @return users
	 * @throws SQLException is an exception sql
	 */
	public List<User> getUniversityUsers(int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.user.get.university"));
		statement.setInt(1, idUniversity);
		ResultSet result = statement.executeQuery();
		List<User> users = new ArrayList<User>();
		UserGroupDAO groupDao = new UserGroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String name = result.getString(2);
			String login = result.getString(3);
			String password = result.getString(4);
			int isOnline = result.getInt(5);
			int idGroup = result.getInt(6);
			users.add(new User(id, name, login, password, isOnline, groupDao.getUserGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return users;
	}

	/**
	 * Method for login user
	 * 
	 * @param id - user's identity
	 * @throws SQLException is an exception sql
	 */
	public void loginUser(int id) throws SQLException {
		logout();
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.login"));
		statement.setInt(1, id);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for logout users
	 * 
	 * @throws SQLException is an exception sql
	 */
	public void logout() throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.logout"));
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for update user
	 * 
	 * @param id       - user's identity
	 * @param name     - user's name
	 * @param login    - user's login
	 * @param password - user's password
	 * @param idGroup  - group's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateUser(int id, String name, String login, String password, int idGroup) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.update"));
		statement.setString(1, name);
		statement.setString(2, login);
		statement.setString(3, password);
		statement.setInt(4, idGroup);
		statement.setInt(5, id);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for update developer
	 * 
	 * @param id           - user's identity
	 * @param name         - user's name
	 * @param login        - user's login
	 * @param password     - user's password
	 * @param idGroup      - group's identity
	 * @param idUniversity - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateUser(int id, String name, String login, String password, int idGroup, int idUniversity)
			throws SQLException {
		updateUser(id, name, login, password, idGroup);
		UniversityDAO dao = new UniversityDAO(connection);
		if (dao.getUserUniversity(id) != null) {
			updateUserUniversity(id, idUniversity);
		} else {
			addUserUniversity(id, idUniversity);
		}

	}

	/**
	 * Method for add developer's university
	 * 
	 * @param idUser       - user's identity
	 * @param idUniversity - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void addUserUniversity(int idUser, int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.user.add.university"));
		statement.setInt(1, idUser);
		statement.setInt(2, idUniversity);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for update developer's university
	 * 
	 * @param idUser       - user's identity
	 * @param idUniversity - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateUserUniversity(int idUser, int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.user.update.university"));
		statement.setInt(1, idUniversity);
		statement.setInt(2, idUser);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for add user
	 * 
	 * @param name     - user's name
	 * @param login    - user's login
	 * @param password - user's password
	 * @param idGroup  - group's identity
	 * @throws SQLException is an exception sql
	 */
	public void addUser(String name, String login, String password, int idGroup) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.add"));
		statement.setString(1, name);
		statement.setString(2, login);
		statement.setString(3, password);
		statement.setInt(4, idGroup);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for add developer
	 * 
	 * @param name         - user's name
	 * @param login        - user's login
	 * @param password     - user's password
	 * @param idGroup      - group's identity
	 * @param idUniversity - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void addUser(String name, String login, String password, int idGroup, int idUniversity) throws SQLException {
		addUser(name, login, password, idGroup);
		User user = getUserByLoginAndPassword(login, password);
		UniversityDAO dao = new UniversityDAO(connection);
		if (dao.getUserUniversity(user.getId()) != null) {
			updateUserUniversity(user.getId(), idUniversity);
		} else {
			addUserUniversity(user.getId(), idUniversity);
		}
	}

	/**
	 * Method for delete user
	 * 
	 * @param id           - user's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteUser(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.user.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
		statement.close();
	}

}
