package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.EducationForm;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity decree's education
 * form
 * 
 * @author Parshina Anna
 *
 */
public class EducationFormDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public EducationFormDAO(Connection connection) {
		EducationFormDAO.connection = connection;
	}

	/**
	 * Method for get education form by id
	 * 
	 * @param id - education form's identity
	 * @return education form
	 * @throws SQLException is an exception sql
	 */
	public EducationForm getEducationFormById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationForm.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		EducationForm form = null;
		while (result.next()) {
			String title = result.getString(2);
			form = new EducationForm(id, title);
		}
		result.close();
		statement.close();
		return form;
	}

	/**
	 * Method for get all education forms
	 * 
	 * @return education forms
	 * @throws SQLException is an exception sql
	 */
	public List<EducationForm> getEducationForms() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationForm.get.all"));
		ResultSet result = statement.executeQuery();
		List<EducationForm> forms = new ArrayList<EducationForm>();
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			forms.add(new EducationForm(id, title));
		}
		result.close();
		statement.close();
		return forms;
	}

	/**
	 * Method for update education form
	 * 
	 * @param id    - education form's identity
	 * @param title - education form's title
	 * @throws SQLException is an exception sql
	 */
	public void updateEducationForm(int id, String title) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationForm.update"));
		statement.setString(1, title);
		statement.setInt(2, id);
		statement.executeUpdate();
	}

	/**
	 * Method for add education form
	 * 
	 * @param title - education form's title
	 * @throws SQLException is an exception sql
	 */
	public void addEducationForm(String title) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationForm.add"));
		statement.setString(1, title);
		statement.executeUpdate();
	}

	/**
	 * Method for update education form
	 * 
	 * @param id - education form's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteEducationForm(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.educationForm.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
