package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.Decree;
import ru.rsreu.studentsregistration.dao.data.Student;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity decree 
 * @author Parshina Anna
 *
 */
public class DecreeDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public DecreeDAO(Connection connection) {
		DecreeDAO.connection = connection;
	}

	/**
	 * Method for get decree by id
	 * @param id - decree's identity
	 * @return decree
	 * @throws SQLException is an exception sql
	 */
	public Decree getDecreeById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.decree.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		Decree decree = null;
		DecreeTypeDAO types = new DecreeTypeDAO(connection);
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			String title = result.getString(2);
			Date date = result.getDate(3);
			int isSigned = result.getInt(4);
			int idType = result.getInt(5);
			int idGroup = result.getInt(6);
			decree = new Decree(id, title, date, isSigned, types.getDecreeTypeById(idType),
					group.getGroupById(idGroup));
		}
		result.close();
		statement.close();
		return decree;
	}

	/**
	 * Method for get last decree
	 * @return decree
	 * @throws SQLException is an exception sql
	 */
	public Decree getDecreeLast() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.decree.get.last"));
		ResultSet result = statement.executeQuery();
		Decree decree = null;
		DecreeTypeDAO types = new DecreeTypeDAO(connection);
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			Date date = result.getDate(3);
			int isSigned = result.getInt(4);
			int idType = result.getInt(5);
			int idGroup = result.getInt(6);
			decree = new Decree(id, title, date, isSigned, types.getDecreeTypeById(idType),
					group.getGroupById(idGroup));
		}
		result.close();
		statement.close();
		return decree;
	}

	/**
	 * Method for get all decrees
	 * @return decrees
	 * @throws SQLException is an exception sql
	 */
	public List<Decree> getDecrees() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.decree.get.all"));
		ResultSet result = statement.executeQuery();
		List<Decree> decrees = new ArrayList<Decree>();
		DecreeTypeDAO types = new DecreeTypeDAO(connection);
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			Date date = result.getDate(3);
			int isSigned = result.getInt(4);
			int idType = result.getInt(5);
			int idGroup = result.getInt(6);
			decrees.add(new Decree(id, title, date, isSigned, types.getDecreeTypeById(idType),
					group.getGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return decrees;
	}

	/**
	 * Method for get university's decrees
	 * @param id - university's identity
	 * @return decrees
	 * @throws SQLException is an exception sql
	 */
	public List<Decree> getUniversityDecrees(int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.decree.get.university"));
		statement.setInt(1, idUniversity);
		ResultSet result = statement.executeQuery();
		List<Decree> decrees = new ArrayList<Decree>();
		DecreeTypeDAO types = new DecreeTypeDAO(connection);
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			Date date = result.getDate(3);
			int isSigned = result.getInt(4);
			int idType = result.getInt(5);
			int idGroup = result.getInt(6);
			decrees.add(new Decree(id, title, date, isSigned, types.getDecreeTypeById(idType),
					group.getGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return decrees;
	}
	
	/**
	 * Method for update decree
	 * @param id - decree's identity
	 * @param title - decree's title
	 * @throws SQLException is an exception sql
	 */
	public void updateDecree(int id, String title) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decree.update"));
		statement.setString(1, title);
		statement.setInt(2, id);
		statement.executeUpdate();
		statement.close();
	}
	
	/**
	 * Method for signed decree
	 * @param id - decree's identity
	 * @throws SQLException is an exception sql
	 */
	public void signed(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decree.signed"));
		statement.setInt(1, id);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for signed decree
	 * @param id - decree's identity
	 * @throws SQLException is an exception sql
	 */
	public void signedDecree(int id) throws SQLException {
		signed(id);
		Decree decree = getDecreeById(id);
		List<Student> students = decree.getStudents();
		StudentDAO dao = new StudentDAO(connection);
		for (Student student : students) {
			if (decree.getType().getTitle().equals("����������")) {
				dao.expulsionStudent(student.getId());
			} else {
				dao.updateGroupStudent(student.getId(), decree.getGroup().getId());
			}
		}
		
	}
	

	/**
	 * Method for add decree
	 * @param title - decree's title
	 * @param date - decree's date
	 * @param idType - decree's type identity
	 * @param idGroup - decree's group identity
	 * @throws SQLException is an exception sql
	 */
	private void addDecree(String title, Date date, int idType, int idGroup) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decree.add"));
		statement.setString(1, title);
		statement.setDate(2, date);
		statement.setInt(3, idType);
		statement.setInt(4, idGroup);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for add decree
	 * @param title - decree's title
	 * @param date - decree's date
	 * @param idType - decree's type identity
	 * @param idGroup - decree's group identity
	 * @param students - decree's - students
	 * @throws SQLException is an exception sql
	 */
	public void addDecree(String title, Date date, int idType, int idGroup, List<Student> students)
			throws SQLException {
		addDecree(title, date, idType, idGroup);
		Decree decree = getDecreeLast();
		StudentDAO dao = new StudentDAO(connection);
		for (Student student : students) {
			if (decree.getType().getTitle().equals("����������")) {
				dao.addStudentDecree(student.getFirstName(), student.getSecondName(), student.getPatronymic(),
						student.getSex(), student.getBirthDate().toString(), decree.getId());
			} else {
				dao.addStudentDecree(student.getId(), decree.getId());
			}
		}
	}

	/**
	 * Method for delete decree
	 * @param id - decree's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteDecree(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decree.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
		statement.close();
	}
}
