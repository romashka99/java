package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.Student;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity student
 * 
 * @author Parshina Anna
 *
 */
public class StudentDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public StudentDAO(Connection connection) {
		StudentDAO.connection = connection;
	}

	/**
	 * Method for get student by id
	 * 
	 * @param id - student's identity
	 * @return student
	 * @throws SQLException is an exception sql
	 */
	public Student getStudentById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		Student student = null;
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			String firstName = result.getString(2);
			String secondName = result.getString(3);
			String patronymic = result.getString(4);
			String sex = result.getString(5);
			Date birthDate = result.getDate(6);
			int idGroup = result.getInt(7);
			student = new Student(id, firstName, secondName, patronymic, sex, birthDate, group.getGroupById(idGroup));
		}
		result.close();
		statement.close();
		return student;
	}

	/**
	 * Method for get last student
	 * 
	 * @return student
	 * @throws SQLException is an exception sql
	 */
	public int getIdStudentLast() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.get.last.id"));
		ResultSet result = statement.executeQuery();
		int id = 0;
		while (result.next()) {
			id = result.getInt(1);
		}
		result.close();
		statement.close();
		return id;
	}

	/**
	 * Method for get all students
	 * 
	 * @return students
	 * @throws SQLException is an exception sql
	 */
	public List<Student> getStudents() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.get.all"));
		ResultSet result = statement.executeQuery();
		List<Student> students = new ArrayList<Student>();
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String firstName = result.getString(2);
			String secondName = result.getString(3);
			String patronymic = result.getString(4);
			String sex = result.getString(5);
			Date birthDate = result.getDate(6);
			int idGroup = result.getInt(7);
			students.add(
					new Student(id, firstName, secondName, patronymic, sex, birthDate, group.getGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return students;
	}

	/**
	 * Method for get group's students
	 * 
	 * @param idGroup - group's identity
	 * @return students
	 * @throws SQLException is an exception sql
	 */
	public List<Student> getGroupStudents(int idGroup) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.get.group"));
		statement.setInt(1, idGroup);
		ResultSet result = statement.executeQuery();
		List<Student> students = new ArrayList<Student>();
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String firstName = result.getString(2);
			String secondName = result.getString(3);
			String patronymic = result.getString(4);
			String sex = result.getString(5);
			Date birthDate = result.getDate(6);
			students.add(
					new Student(id, firstName, secondName, patronymic, sex, birthDate, group.getGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return students;
	}

	/**
	 * Method for get university's students
	 * 
	 * @param idUniversity - university's identity
	 * @return students
	 * @throws SQLException is an exception sql
	 */
	public List<Student> getUniversityStudents(int idUniversity) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.get.university"));
		statement.setInt(1, idUniversity);
		ResultSet result = statement.executeQuery();
		List<Student> students = new ArrayList<Student>();
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String firstName = result.getString(2);
			String secondName = result.getString(3);
			String patronymic = result.getString(4);
			String sex = result.getString(5);
			Date birthDate = result.getDate(6);
			int idGroup = result.getInt(7);
			students.add(
					new Student(id, firstName, secondName, patronymic, sex, birthDate, group.getGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return students;
	}

	/**
	 * Method for get decree's students
	 * 
	 * @param idDecree - decree's identity
	 * @return students
	 * @throws SQLException is an exception sql
	 */
	public List<Student> getDecreeStudents(int idDecree) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.get.decree"));
		statement.setInt(1, idDecree);
		ResultSet result = statement.executeQuery();
		List<Student> students = new ArrayList<Student>();
		GroupDAO group = new GroupDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String firstName = result.getString(2);
			String secondName = result.getString(3);
			String patronymic = result.getString(4);
			String sex = result.getString(5);
			Date birthDate = result.getDate(6);
			int idGroup = result.getInt(7);
			students.add(
					new Student(id, firstName, secondName, patronymic, sex, birthDate, group.getGroupById(idGroup)));
		}
		result.close();
		statement.close();
		return students;
	}

	/**
	 * Method for update student
	 * 
	 * @param id         - student's identity
	 * @param firstName  - student's first name
	 * @param secondName - student's second name
	 * @param patronymic - student's patronymic
	 * @param sex        - student's sex
	 * @param birthDate  - student's birth date
	 * @throws SQLException is an exception sql
	 */
	public void updateStudent(int id, String firstName, String secondName, String patronymic, String sex,
			String birthDate) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.update"));
		statement.setString(1, firstName);
		statement.setString(2, secondName);
		statement.setString(3, patronymic);
		statement.setString(4, sex);
		statement.setString(5, birthDate);
		statement.setInt(6, id);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for add student
	 * 
	 * @param firstName  - student's first name
	 * @param secondName - student's second name
	 * @param patronymic - student's patronymic
	 * @param sex        - student's sex
	 * @param birthDate  - student's birth date
	 * @throws SQLException is an exception sql
	 */
	public void addStudent(String firstName, String secondName, String patronymic, String sex, String birthDate)
			throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.student.add"));
		statement.setString(1, firstName);
		statement.setString(2, secondName);
		statement.setString(3, patronymic);
		statement.setString(4, sex);
		statement.setString(5, birthDate);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for add student in decree
	 * 
	 * @param idStudent - student's identity
	 * @param idDecree  - decree's identity
	 * @throws SQLException is an exception sql
	 */
	public void addStudentDecree(int idStudent, int idDecree) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.add.decree"));
		statement.setInt(1, idStudent);
		statement.setInt(2, idDecree);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for add new student in decree
	 * 
	 * @param firstName  - student's first name
	 * @param secondName - student's second name
	 * @param patronymic - student's patronymic
	 * @param sex        - student's sex
	 * @param birthDate  - student's birth date
	 * @param idDecree   - decree's identity
	 * @throws SQLException is an exception sql
	 */
	public void addStudentDecree(String firstName, String secondName, String patronymic, String sex, String birthDate,
			int idDecree) throws SQLException {
		addStudent(firstName, secondName, patronymic, sex, birthDate);
		addStudentDecree(getIdStudentLast(), idDecree);
	}

	/**
	 * Method for update student's group
	 * 
	 * @param idStudent - student's identity
	 * @param idGroup   - group's identity
	 * @throws SQLException is an exception sql
	 */
	public void updateGroupStudent(int idStudent, int idGroup) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.update.group"));
		statement.setInt(1, idGroup);
		statement.setInt(2, idStudent);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for expulsion student
	 * 
	 * @param idStudent - student's identity
	 * @throws SQLException is an exception sql
	 */
	public void expulsionStudent(int idStudent) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.expulsion"));
		statement.setInt(1, idStudent);
		statement.executeUpdate();
		statement.close();
	}

	/**
	 * Method for delete student
	 * 
	 * @param id - student's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteStudent(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.student.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
		statement.close();
	}
}
