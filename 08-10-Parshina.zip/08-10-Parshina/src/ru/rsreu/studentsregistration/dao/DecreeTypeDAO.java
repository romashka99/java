package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.DecreeType;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity decree's type 
 * @author Parshina Anna
 *
 */
public class DecreeTypeDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;
	
	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public DecreeTypeDAO(Connection connection) {
		DecreeTypeDAO.connection = connection;
	}
	
	/**
	 * Method for get decree's type by id
	 * @param id - decree's type identity
	 * @return type
	 * @throws SQLException is an exception sql
	 */
	public DecreeType getDecreeTypeById(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decreeType.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		DecreeType decreeType = null;
		while (result.next()) {
			String title = result.getString(2);
			decreeType = new DecreeType(id, title);
		}
		result.close();
		statement.close();
		return decreeType;
	}
	
	/**
	 * Method for get all decree's type
	 * @return types
	 * @throws SQLException is an exception sql
	 */
	public List<DecreeType> getDecreeTypes() throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decreeType.get.all"));
		ResultSet result = statement.executeQuery();
		List<DecreeType> decrees = new ArrayList<DecreeType>();
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			decrees.add(new DecreeType(id, title));
		}
		result.close();
		statement.close();
		return decrees;
	}
	
	/**
	 * Method for update decree's type
	 * @param id - decree's type identity
	 * @param title - decree's type title
	 * @throws SQLException is an exception sql
	 */
	public void updateDecreeType(int id, String title) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decreeType.update"));
		statement.setString(1, title);
		statement.setInt(2, id);
		statement.executeUpdate();
	}
	
	/**
	 * Method for add decree's type
	 * @param title - decree's type title
	 * @throws SQLException is an exception sql
	 */
	public void addDecreeType(String title) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decreeType.add"));
		statement.setString(1, title);
		statement.executeUpdate();
	}
	
	/**
	 * Method for delete decree's type
	 * @param id - decree's type identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteDecreeType(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(QueriesManager.getString("sql.quaery.decreeType.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
