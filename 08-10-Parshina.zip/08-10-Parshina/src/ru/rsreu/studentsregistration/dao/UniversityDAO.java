package ru.rsreu.studentsregistration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ru.rsreu.studentsregistration.dao.data.University;
import ru.rsreu.studentsregistration.resources.QueriesManager;

/**
 * Class for writing data from the database for an entity university
 * 
 * @author Parshina Anna
 *
 */
public class UniversityDAO {
	/**
	 * Connection database
	 */
	private static Connection connection;

	/**
	 * Constructor with parameters
	 * 
	 * @param connection - connection database
	 */
	public UniversityDAO(Connection connection) {
		UniversityDAO.connection = connection;
	}

	/**
	 * Method for get university by id
	 * 
	 * @param id - university's identity
	 * @return university
	 * @throws SQLException is an exception sql
	 */
	public University getUniversityById(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.university.get.one"));
		statement.setInt(1, id);
		ResultSet result = statement.executeQuery();
		University university = null;
		UserDAO users = new UserDAO(connection);
		while (result.next()) {
			String title = result.getString(2);
			String article = result.getString(3);
			String adress = result.getString(4);
			university = new University(id, title, article, adress, users.getUniversityUsers(id));
		}
		result.close();
		statement.close();
		return university;
	}

	/**
	 * Method for get user's university
	 * 
	 * @param idUser - users's identity
	 * @return university
	 * @throws SQLException is an exception sql
	 */
	public University getUserUniversity(int idUser) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.university.get.user"));
		statement.setInt(1, idUser);
		ResultSet result = statement.executeQuery();
		University university = null;
		UserDAO users = new UserDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			String article = result.getString(3);
			String adress = result.getString(4);
			university = new University(id, title, article, adress, users.getUniversityUsers(id));
		}
		result.close();
		statement.close();
		return university;
	}

	/**
	 * Method for get all universities
	 * 
	 * @return universities
	 * @throws SQLException is an exception sql
	 */
	public List<University> getUniversities() throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.university.get.all"));
		ResultSet result = statement.executeQuery();
		List<University> universities = new ArrayList<University>();
		UserDAO users = new UserDAO(connection);
		while (result.next()) {
			int id = result.getInt(1);
			String title = result.getString(2);
			String article = result.getString(3);
			String adress = result.getString(4);
			universities.add(new University(id, title, article, adress, users.getUniversityUsers(id)));
		}
		result.close();
		statement.close();
		return universities;
	}

	/**
	 * Method for update university
	 * 
	 * @param id      - university's identity
	 * @param title   - university's title
	 * @param article - university's article
	 * @param adress  - university's adress
	 * @throws SQLException is an exception sql
	 */
	public void updateUniversity(int id, String title, String article, String adress) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.university.update"));
		statement.setString(1, title);
		statement.setString(2, article);
		statement.setString(3, adress);
		statement.setInt(4, id);
		statement.executeUpdate();
	}

	/**
	 * Method for update university
	 * 
	 * @param title   - university's title
	 * @param article - university's article
	 * @param adress  - university's adress
	 * @throws SQLException is an exception sql
	 */
	public void addUniversity(String title, String article, String adress) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.university.add"));
		statement.setString(1, title);
		statement.setString(2, article);
		statement.setString(3, adress);
		statement.executeUpdate();
	}

	/**
	 * Method for update university
	 * 
	 * @param id - university's identity
	 * @throws SQLException is an exception sql
	 */
	public void deleteUniversity(int id) throws SQLException {
		PreparedStatement statement = connection
				.prepareStatement(QueriesManager.getString("sql.quaery.university.delete"));
		statement.setInt(1, id);
		statement.executeUpdate();
	}

}
