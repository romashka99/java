$(document).ready(function() {
  $('#facultyTable').DataTable();
  $('#departmentTable').DataTable();
  $('#groupTable').DataTable();
  $('#studentTable').DataTable();
  $('#specialtyTable').DataTable();
  $('#levelTable').DataTable();
  $('#formTable').DataTable();

});