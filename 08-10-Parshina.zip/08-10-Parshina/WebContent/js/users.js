$(document).ready(function() {
	ChangeGroup('#group');
	$('#group').change(function() {
		ChangeGroup(this);
	});
});

function ChangeGroup(group) {
	if($(group).val() == 1) {
		$('#university').show();
	} else {
		$('#university').hide();
	}
}

function ChangeUser(id, name, login, password, group, university) {
	$('#id-user').val(id);
	$('#name').val(name);
	$('#login').val(login);
	$('#password').val(password);
	$('#group').val(group);
	$('#university').val(university);
}

function ChangeUserGroup(id, title) {
	$('#id-usergroup').val(id);
	$('#title').val(title);
}