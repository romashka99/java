var count = 0;
var students = [];
var selectStudents = students;

$(document).ready(function() {
	
	TypeChange();
	
	$('.delete').click(function(event) {
		event.preventDefault();
		if (confirm('Вы действительно хотите удалить этот приказ?')) {
			window.location.href = this.href;
		} else {
			return false;
		}
	});
	
	$('#submit').click(function(event) {
		if (count == 0) {
			event.preventDefault();
			alert('В приказе нет ни одного студента');
		}
	});
	
	ResetStudents();
	$('#group').change(function() {
		$('#decree-tbody').html('');
		ResetStudents(); 
	});
	
});

function StudentChange() {
	selectStudents = [];
	$('.student-select').each(function() {
		selectStudents.push(Number($(this).val()));
	});
	$('.student-select').each(function() {
		var value = $(this).val();
		var selects = $(this);
		$(this).find('option').each(function() {
			if(!$(this).is(':selected')){
				$(this).remove();
			}
		});
		students.forEach(function(student) {
			if (selectStudents.indexOf(Number(student.id)) < 0) {
				selects.append('<option value="' + student.id + '">' + student.secondName + '</option>');
			}
		});
	});
}

function TypeChange() {
	var thread = '';
	type = $('#type-decree').val();
	if(type == 1) {
		$('#div-group-to').hide();
		$('#lable-group').text("В:");
		thread += '<tr>'
			+ '<th class="text-center"><a href="#add" onclick="AddRowDecree()"><span class="fa fa-plus"></span></a></th>'
			+ '<th>Фамилия</th>'
			+ '<th>Имя</th>'
			+ '<th>Отчество</th>'
			+ '<th>Дата рождения</th>'
			+ '<th>Пол</th>'
			+ '</tr>';
	} else {
		$('#lable-group').text("Из:");
		if(type == 3) {
			$('#div-group-to').show();
		} else {
			$('#div-group-to').hide();
		}
		thread += '<tr>'
			+ '<th class="text-center"><a href="#add" onclick="AddRowDecree()"><span class="fa fa-plus"></span></a></th>'
			+ '<th>Студент</th>'
			+ '</tr>';
	}
	$('#decree-thead').html(thread);
	$('#decree-tbody').html('');
	count = 0;
}

function ObjectForGet() {
	return {
		'group' :  $('#group').val(),
		'type' : $('#type-decree').val(),
		'command' : 'get_student_group'
	}
}



function ResetStudents() {
	invoke(ObjectForGet(), function (resp) {
		students = resp;
		selectStudents = [];
	});
}

function AddRowDecree() {
	var row = '';
	if ($('#type-decree').val() == 1) {
		row += '<tr id="data-row-' + count + '">'
		+ '<td class="text-center"><a href="#delete" onclick="DeleteRowDecree(' + count + ')"><span class="fa fa-minus"></span></a></td>'
		+ '<td><input type="text" class="form-control" name="first-name" required></td>'
		+ '<td><input type="text" class="form-control" name="second-name" required></td>'
		+ '<td><input type="text" class="form-control" name="patronymic" required></td>'
		+ '<td><input type="date" class="form-control" name="birth-date" required></td>'
		+ '<td><select class="form-control" name="sex"><option value="М">Мужской</option><option value="Ж">Женский</option></select></td>'
		+ '/<tr>';
		count += 1;
	} else {
		if (students.length > count) {
			StudentChange();
			row += '<tr id="data-row-' + count + '">'
			+ '<td class="text-center"><a href="#delete" onclick="DeleteRowDecree(' + count + ')"><span class="fa fa-minus"></span></a></td>'
			+ '<td><select class="form-control student-select" name="students" onChange="StudentChange(this)">';
			students.forEach(function(student) {
				if (selectStudents.indexOf(Number(student.id)) < 0) {
					row += '<option value="' + student.id + '">' + student.secondName + '</option>'
				}
			});
			row +='</select></td></tr>';
			count += 1;
		}
	}
	$('#decree-tbody').append(row);
}

function DeleteRowDecree(id) {
	$('#data-row-' + id).remove();
	count -= 1;
}
