function ChangeStudent(id, fname, sname, patr, date, sex){
	$('#id').val(id);
	$('#first-name').val(fname);
	$('#second-name').val(sname);
	$('#patronymic').val(patr);
	$('#sex').val(sex);
	$('#birth-date').val(date);
}