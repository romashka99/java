function invoke(args, callback) {
	var apiUrl = appName + '/controller';
	invokeApi(apiUrl, args, callback);
}

function invokeApi(apiUrl, args, callback) {
    $.post(apiUrl, args).done(function (resp) {
        callback((resp) ? JSON.parse(resp) : undefined);
    })
}