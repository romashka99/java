$(document).ready(function() {
	$('.delete').click(function(event) {
		event.preventDefault();
		if (confirm('Вы действительно хотите удалить этот элемент?')) {
			window.location.href = this.href;
		} else {
			return false;
		}
	});
})